# Security & Trust Notes — P3 v0.4.1

P3 implements bounded public-trial controls. This is **not** a security certification or production assurance claim.

## Trust boundaries
- User text, QR, image and identifiers are untrusted input.
- Secret redaction precedes the deterministic decision path.
- QR decode is observation only; it has no unilateral safety authority.
- Generic image OCR remains out of scope.
- Model/provider calls are absent from the decision path.
- Deterministic policy retains action authority.

## Public edge controls
- TrustedHost middleware.
- HSTS when `PAR_PUBLIC_HTTPS=1`.
- CSP, anti-frame, nosniff, no-referrer, COOP/CORP and restrictive Permissions Policy.
- No-index/no-archive trial-site header plus `robots.txt` disallow.
- Request IDs and bounded in-memory rate limiting.
- Uvicorn server header disabled.
- Proxy headers enabled only at the runtime boundary; forwarded-IP trust is deployment-configurable.

## Runtime/container
- Non-root UID 10001.
- Pinned production dependencies separated from test tooling.
- No credentials or private institutional data are required.
- Health/readiness endpoint is explicit.

## Known limitations
- In-memory rate limiting is single-replica only.
- SQLite is single-replica local state; no distributed locking/HA.
- No account/authentication layer.
- No formal penetration test, SAST/DAST certification or external security audit.
- Public URL security must be re-checked after deployment.
