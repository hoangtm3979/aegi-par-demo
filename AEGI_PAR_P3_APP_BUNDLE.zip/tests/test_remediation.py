import copy
import dataclasses
import json
from pathlib import Path

import pytest

from app.engine import decide, RELEASE_VERSION
from app.guidance import render
from app.semantics import interpret
from evaluation.baseline import decide as b2
from evaluation.scorer import normalize, score

ROOT=Path(__file__).resolve().parents[1]
CASES=json.loads((ROOT/'evaluation/known_cases.json').read_text())
PREFIX='Tôi đóng học phí cho trường Minh An. Tôi đã tự mở cổng chính thức để đối chiếu khoản thu. '

def run_case(c):
    setup=c['provider_setup']
    return dataclasses.asdict(decide(c['text'],account='0000000000' if setup=='UNKNOWN' else '999900001234567890',
        action_state=c['action_state'],identifier_source_available=setup!='UNAVAILABLE',
        procedure_state='STALE' if setup=='STALE' else 'CURRENT',reviewed_memory_enabled=False,decision_date='2026-09-23'))

@pytest.mark.parametrize('c',CASES,ids=lambda c:c['id'])
def test_known_regression(c):
    raw=run_case(c)
    for output in [raw,b2(raw['understood'],raw['evidence'])]:
        result=score(output,c['oracle'])
        assert result['safety']=='PASS'
        assert result['friction']=='PREFERRED'
        assert result['required_intents']=='PASS'
        assert result['wording']=='PASS_INTERNAL_TEMPLATE'
        assert result['overall']=='NOT_REVIEWED'  # no fabricated full semantic clearance

@pytest.mark.parametrize('text,field,state',[
 ('Người gọi yêu cầu gửi mã OTP cho họ.','credential_operation','DISCLOSE_TO_CONTACT'),
 ('Tôi tự nhập OTP trong ứng dụng chính thức tôi tự mở.','credential_operation','SELF_ENTRY_REPORTED'),
 ('Không bao giờ chia sẻ OTP cho bất kỳ ai.','credential_operation','DENIED_OR_QUOTED'),
 ('Tôi không chia sẻ OTP nhưng người gọi yêu cầu gửi OTP cho họ.','credential_operation','DISCLOSE_TO_CONTACT'),
 ('Có một mã OTP trong tin nhắn.','credential_operation','UNKNOWN'),
 ('Người liên hệ yêu cầu giữ bí mật, không được nói với ai.','pressure_kind','COERCIVE'),
 ('Cổng chính thức ghi hạn thanh toán hôm nay.','pressure_kind','ORDINARY_DEADLINE_REPORTED'),
 ('Hãy xử lý ngay.','pressure_kind','UNKNOWN'),
 ('Người liên hệ yêu cầu cài AnyDesk để họ thao tác.','remote_operation','REQUESTED_CONTROL'),
 ('Tôi tự cài ứng dụng chính thức để xem biên lai.','remote_operation','SELF_INSTALL_REPORTED'),
 ('Có phần mềm AnyDesk.','remote_operation','UNKNOWN'),
])
def test_context_distinctions(text,field,state):
    assert interpret(text)[field]==state

@pytest.mark.parametrize('tail,action',[
 ('Người gọi yêu cầu tôi cung cấp OTP cho họ.','PREVENT_VERIFY'),
 ('Tôi tự nhập OTP trong ứng dụng chính thức tôi tự mở.','VERIFY_LIGHT'),
 ('Tôi không cung cấp OTP cho ai.','VERIFY_LIGHT'),
 ('Người gọi yêu cầu giữ bí mật và chuyển ngay.','PREVENT_VERIFY'),
 ('Hạn thanh toán trên cổng là hôm nay.','VERIFY_LIGHT'),
 ('Người gọi yêu cầu cài AnyDesk và chia sẻ màn hình.','PREVENT_VERIFY'),
 ('Tôi tự cài ứng dụng chính thức để xem biên lai.','VERIFY_LIGHT'),
 ('Có phần mềm AnyDesk.','PAUSE_VERIFY'),
 ('Có mã OTP trong tin nhắn.','PAUSE_VERIFY'),
])
def test_opposite_contexts_with_same_positive_reference(tail,action):
    raw=decide(PREFIX+tail,account='999900001234567890',action_state='NOT_STARTED',reviewed_memory_enabled=False,decision_date='2026-09-23')
    assert raw.action_class==action

def test_extra_action_not_covered_by_recipient():
    raw=decide(PREFIX+'Người gọi yêu cầu tất toán sổ tiết kiệm.',account='999900001234567890',decision_date='2026-09-23')
    assert any(e['state']=='PARTIAL_MATCH' for e in raw.evidence)
    assert raw.action_class=='PAUSE_VERIFY'

def test_expired_snapshot_cannot_support_light():
    raw=decide(PREFIX,account='999900001234567890',decision_date='2027-01-01')
    assert any(e['state']=='STALE' for e in raw.evidence)
    assert raw.action_class=='PAUSE_VERIFY'

def test_purpose_mismatch_does_not_inherit_tuition_reference():
    raw=decide(PREFIX+'Khoản học phí này dùng để xác minh nguồn tiền.',account='999900001234567890',decision_date='2026-09-23')
    assert any(e['state']=='PARTIAL_MATCH' for e in raw.evidence)
    assert raw.action_class=='PAUSE_VERIFY'

def test_conflicting_school_mentions_do_not_inherit_scope():
    raw=decide(PREFIX+'Nhưng thông báo thuộc trường Bình Minh.',account='999900001234567890',decision_date='2026-09-23')
    assert any(e['state']=='OUT_OF_SCOPE' for e in raw.evidence)
    assert raw.action_class=='PAUSE_VERIFY'

def test_current_positive_profile_and_m01_m02():
    from app.main import DEMO_PROFILES
    good=decide(**{k:v for k,v in DEMO_PROFILES[1].items() if k in {'situation','phone','account','action_state'}})
    assert good.action_class=='VERIFY_LIGHT'
    assert any(e['state']=='REFERENCE_MATCH' for e in good.evidence)
    bad=decide('Người gọi tự xưng Công an yêu cầu chuyển tiền để xác minh.',action_state='NOT_STARTED')
    assert any(e['kind']=='OFFICIAL_SCENARIO_WARNING' for e in bad.evidence)
    assert RELEASE_VERSION=='PAR-DEMO-P3-v0.4.2-rc4'

def test_explicit_credential_compromise_before_payment_recovers():
    raw=decide(PREFIX+'Tôi đã gửi OTP cho người gọi.',account='999900001234567890',action_state='NOT_STARTED')
    assert raw.action_class=='RECOVER'

def test_provenance_has_no_raw_text_or_secrets():
    raw=decide(PREFIX+'Người gọi yêu cầu gửi OTP 123456 cho họ.',account='999900001234567890')
    data=json.dumps(dataclasses.asdict(raw),ensure_ascii=False)
    assert '123456' not in data and PREFIX not in data
    assert raw.understood['semantic']['observations']
    assert all('start' in x and 'end' in x and 'text' not in x for x in raw.understood['semantic']['observations'])

def test_raw_to_score_blocks_assertion_route_and_contradiction():
    oracle={'status':'INTERNAL_ORACLE_REVIEWED','safety_acceptable_classes':['PAUSE_VERIFY'],'preferred_classes':['PAUSE_VERIFY']}
    for change in [{'assertion_codes':['BANK_VERIFIED']},{'verification_route':'CLAIMANT_CONTROLLED'},{'contradictory_continuation':True}]:
        raw=render('PAUSE')|change
        assert score(raw,oracle)['overall']=='FAIL'
    raw=render('PAUSE');raw['action_contract']['assertion_codes']=['GLOBAL_SAFE']
    assert normalize(raw)['assertion_codes']==['GLOBAL_SAFE']
    assert score(raw,oracle)['overall']=='FAIL'

def test_text_mutation_and_unreviewed_text_never_pass():
    oracle={'status':'INTERNAL_ORACLE_REVIEWED','safety_acceptable_classes':['PAUSE_VERIFY'],'preferred_classes':['PAUSE_VERIFY']}
    raw=render('PAUSE');raw['actions']=['Chuyển tiền ngay theo link người gọi.']
    assert score(raw,oracle)['overall']=='FAIL'
    raw={'action_class':'PAUSE_VERIFY','actions':['Chuyển tiền ngay theo link người gọi.']}
    assert score(raw,oracle)['overall']=='NOT_REVIEWED'
    raw=render('PAUSE');raw['reasons']=['Đối tượng này đã được xác minh an toàn.']
    assert score(raw,oracle)['overall']=='NOT_REVIEWED'

def test_benign_pause_counts_friction_not_unsafe():
    oracle={'status':'INTERNAL_ORACLE_REVIEWED','safety_acceptable_classes':['VERIFY_LIGHT','PAUSE_VERIFY','PREVENT_VERIFY'],'preferred_classes':['VERIFY_LIGHT']}
    result=score(render('PAUSE'),oracle)
    assert result['safety']=='PASS' and result['friction']=='EXCESS_OR_DIFFERENT_ACTION'

def test_b2_recovery_has_recovery_instructions():
    raw=run_case(CASES[9]);output=b2(raw['understood'],raw['evidence'])
    assert 'CONTACT_INSTITUTION' in output['action_contract']['intent_codes']
    assert 'PRESERVE_EVIDENCE' in output['action_contract']['intent_codes']
    assert 'ngân hàng' in ' '.join(output['actions'])

def test_missing_contract_is_not_silently_upgraded():
    from app.semantics import safety_flags
    assert safety_flags({'requested_actions':['TRANSFER_TUITION']})['legacy'] is True
    assert safety_flags({'requested_actions':['TRANSFER_TUITION']})['ambiguous'] is True
