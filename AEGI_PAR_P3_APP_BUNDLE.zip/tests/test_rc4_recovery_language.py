from app.engine import decide
from app.security import redact_secrets


def projection(text):
    r = decide(text, decision_date="2026-09-23", reviewed_memory_enabled=False)
    return r.action_class, r.understood["semantic"]["exposure"]


def test_password_to_caller_is_recovery_not_redaction_artifact():
    red = redact_secrets("Tôi đã gửi mật khẩu cho người gọi.")
    assert "[ĐÃ ẨN]" not in red.text
    action, exp = projection("Tôi đã gửi mật khẩu cho người gọi.")
    assert action == "RECOVER"
    assert exp["credential"] == "YES"


def test_real_password_literal_still_redacted_without_exposure_inference():
    red = redact_secrets("Tôi cần kiểm tra. Mật khẩu: secret123")
    assert "secret123" not in red.text
    action, exp = projection("Tôi cần kiểm tra. Mật khẩu: secret123")
    assert exp["credential"] == "UNKNOWN"


def test_colloquial_remote_control_completed():
    action, exp = projection("Tui đưa mã vô máy cho người ta điều khiển rồi.")
    assert action == "RECOVER"
    assert exp["control"] == "YES"


def test_control_negation_is_no():
    action, exp = projection("Tôi chưa cho điều khiển máy.")
    assert exp["control"] == "NO"
    assert action != "RECOVER"


def test_colloquial_ck_and_generic_code_to_caller():
    action, exp = projection("Em chưa ck, nhưng mã vừa nhắn cho ông gọi điện rồi.")
    assert exp["payment"] == "NO"
    assert exp["credential"] == "YES"
    assert action == "RECOVER"


def test_generic_code_request_but_not_sent_is_not_exposure():
    action, exp = projection("Người gọi bảo gửi mã, nhưng tôi chưa gửi gì cho họ.")
    assert exp["credential"] in {"NO", "UNKNOWN"}
    assert action != "RECOVER"
