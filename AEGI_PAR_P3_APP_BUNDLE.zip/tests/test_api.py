from io import BytesIO

import qrcode
from fastapi.testclient import TestClient
from PIL import Image

from app.main import app

client = TestClient(app)


def _hero1_payload(**extra):
    payload = {
        'situation': 'Người gọi tự xưng Công an yêu cầu chuyển tiền để xác minh. Tôi chưa chuyển.',
        'phone': '0909123456',
        'account': '123456789012',
        'action_state': 'NOT_STARTED',
    }
    payload.update(extra)
    return payload


def _png_bytes(size=(100, 80)):
    bio = BytesIO()
    Image.new('RGB', size, 'white').save(bio, format='PNG')
    return bio.getvalue()


def _qr_bytes(value='https://example.org/verify-demo'):
    bio = BytesIO()
    img = qrcode.make(value)
    img.save(bio, format='PNG')
    return bio.getvalue()


def test_health_ready_and_security_headers():
    r = client.get('/api/v1/health')
    assert r.status_code == 200
    assert r.json()['release'] == 'PAR-DEMO-P3-v0.4.2-rc4'
    assert r.headers['x-frame-options'] == 'DENY'
    assert "object-src 'none'" in r.headers['content-security-policy']
    assert r.headers['cross-origin-resource-policy'] == 'same-origin'
    ready = client.get('/api/v1/readyz')
    assert ready.status_code == 200
    assert ready.json()['ready'] is True


def test_profiles_are_three_bounded_proofs():
    r = client.get('/api/v1/demo/profiles')
    assert r.status_code == 200
    ids = [p['id'] for p in r.json()['profiles']]
    assert ids == ['hero1_unknown_identifier', 'hero2_legitimate_unfamiliar', 'hero3_reviewed_memory']


def test_hero1_roundtrip_persists_without_raw_input():
    r = client.post('/api/v1/check', json=_hero1_payload())
    assert r.status_code == 200
    body = r.json()
    assert body['concern_level'] == 'HIGH_NOT_DONE'
    assert body['persistence']['raw_input_persisted'] is False
    case_id = body['case_id']
    restored = client.get(f'/api/v1/cases/{case_id}')
    assert restored.status_code == 200
    assert restored.json()['trace']['decision_hash'] == body['trace']['decision_hash']
    assert 'Người gọi tự xưng' not in str(restored.json())


def test_legacy_unscoped_hero2_roundtrip_clarifies():
    r = client.post('/api/v1/check', json={
        'situation': 'Tôi nhận tin nhắn đóng học phí của Trường Minh An (DEMO), chưa thanh toán.',
        'phone': '0900000202',
        'account': '999900001234567890',
        'action_state': 'NOT_STARTED'
    })
    assert r.status_code == 200
    assert r.json()['concern_level'] == 'VERIFY'
    assert r.json()['action_class'] == 'PAUSE_VERIFY'


def test_hero3_roundtrip_reviewed_memory():
    r = client.post('/api/v1/check', json={
        'situation': 'Tôi chưa từng mua của người bán này. Người bán mới bảo rời sàn sang Zalo riêng và chuyển khoản đặt cọc vào tài khoản cá nhân để giữ hàng 10 phút. Tôi chưa chuyển tiền.',
        'phone': '0900000303',
        'account': '777700001111222233',
        'action_state': 'NOT_STARTED'
    })
    assert r.status_code == 200
    assert r.json()['concern_level'] == 'HIGH_NOT_DONE'
    assert any(e['state'] == 'SIMILAR_REVIEWED' for e in r.json()['evidence'])


def test_generic_image_acquisition_discards_raw_bytes():
    r = client.post('/api/v1/uploads/image', files={'file': ('evidence.png', _png_bytes(), 'image/png')})
    assert r.status_code == 200
    att = r.json()['attachment']
    assert att['state'] == 'ACCEPTED_METADATA_ONLY'
    assert att['raw_file_persisted'] is False
    assert att['text_extraction'] == 'NOT_PERFORMED'
    assert 'attachment_token' in att


def test_qr_acquisition_decodes_as_observation_then_binds_to_case():
    r = client.post('/api/v1/uploads/image', files={'file': ('qr.png', _qr_bytes(), 'image/png')})
    assert r.status_code == 200
    att = r.json()['attachment']
    assert att['state'] == 'QR_DECODED'
    assert att['qr_payload_type'] == 'URL'
    checked = client.post('/api/v1/check', json=_hero1_payload(attachment_tokens=[att['attachment_token']]))
    assert checked.status_code == 200
    body = checked.json()
    assert body['trace']['attachment_count'] == '1'
    qr_items = [e for e in body['evidence'] if e['kind'] == 'QR_OBSERVATION']
    assert len(qr_items) == 1
    assert qr_items[0]['metadata']['raw_file_persisted'] is False


def test_rejects_wrong_upload_type_and_fake_image():
    r = client.post('/api/v1/uploads/image', files={'file': ('x.txt', b'hello', 'text/plain')})
    assert r.status_code == 400
    r2 = client.post('/api/v1/uploads/image', files={'file': ('x.png', b'not-a-png', 'image/png')})
    assert r2.status_code == 400


def test_expired_or_unknown_attachment_is_not_silently_ignored():
    r = client.post('/api/v1/check', json=_hero1_payload(attachment_tokens=['att_00000000000000000000']))
    assert r.status_code == 410


def test_case_delete_is_explicit_and_irreversible_for_demo_store():
    r = client.post('/api/v1/check', json=_hero1_payload())
    case_id = r.json()['case_id']
    d = client.delete(f'/api/v1/cases/{case_id}')
    assert d.status_code == 200 and d.json()['status'] == 'deleted'
    assert client.get(f'/api/v1/cases/{case_id}').status_code == 404


def test_evidence_endpoint_contains_persistence_boundary():
    r = client.post('/api/v1/check', json=_hero1_payload())
    case_id = r.json()['case_id']
    ev = client.get(f'/api/v1/cases/{case_id}/evidence')
    assert ev.status_code == 200
    assert ev.json()['persistence']['raw_input_persisted'] is False
    assert ev.json()['capability']['generic_image_ocr'] == 'NOT_ENABLED'


def test_input_bounds_enforced():
    r = client.post('/api/v1/check', json={'situation': 'x' * 4001})
    assert r.status_code == 422
