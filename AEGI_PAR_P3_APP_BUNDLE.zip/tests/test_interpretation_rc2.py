import dataclasses
import pytest
from fastapi.testclient import TestClient
from app.main import app
from app.engine import decide
from app.semantics import interpret, fold

@pytest.mark.parametrize('text,key,expected',[
 ('Tôi chưa chuyển tiền nhưng vừa đọc OTP cho người gọi.','credential','YES'),
 ('Tôi đã gửi mã truy cập máy cho người hỗ trợ.','control','YES'),
 ('Nếu tôi đã gửi OTP cho người gọi thì sao?','credential','UNKNOWN'),
 ('Bạn tôi đã gửi OTP cho người gọi.','credential','UNKNOWN'),
 ('Tôi chưa hề tiết lộ OTP cho ai.','credential','NO'),
 ('Tôi đã chuyển tiền. Tôi chưa chuyển tiền.','payment','CONFLICT'),
])
def test_independent_exposures(text,key,expected):
 assert interpret(text)['exposure'][key]==expected

def test_spans_are_exact_and_no_raw_payload():
 text='  Tôi không chia sẻ OTP; nhưng người gọi yêu cầu gửi OTP cho họ. '
 s=interpret(text); folded=fold(text)
 for e in s['observations']:
  assert folded[e['start']:e['end']].strip()==folded[e['start']:e['end']]
  assert 0<=e['start']<e['end']<=len(folded)
  assert 'text' not in e
 assert any(e['state']=='DISCLOSE_TO_CONTACT' and 'nguoi goi' in folded[e['start']:e['end']] for e in s['observations'])

def test_unknown_never_becomes_low():
 r=decide('Tôi được nhờ làm một việc chưa biết có ổn không.')
 assert r.action_class=='PAUSE_VERIFY'
 assert r.understood['semantic']['interpretation_status']=='PARTIAL'
 assert len(r.understood['semantic']['clarifications'])==2

def test_answer_conflict_preserves_recovery():
 r=decide('Tôi vừa gửi OTP cho người gọi.',exposure_answers={'credential':'NO','payment':'NO'})
 assert r.action_class=='RECOVER'
 assert r.understood['semantic']['exposure']['credential']=='CONFLICT'
 assert r.understood['semantic']['exposure']['payment']=='NO'

def test_positive_answer_unknown_causes_recovery_without_payment():
 r=decide('Người gọi đang trao đổi với tôi.',exposure_answers={'credential':'YES','payment':'NO'})
 assert r.action_class=='RECOVER'
 assert r.understood['action_state']=='NOT_STARTED'

def test_control_answer_causes_recovery():
 assert decide('Tôi cần kiểm tra yêu cầu này.',exposure_answers={'control':'YES'}).action_class=='RECOVER'

def test_api_typed_answers_and_persistence():
 c=TestClient(app)
 r=c.post('/api/v1/check',json={'situation':'Tôi cần kiểm tra yêu cầu này.','exposure_answers':{'payment':'NO','credential':'YES'}})
 assert r.status_code==200
 d=r.json();assert d['action_class']=='RECOVER'
 assert c.get('/api/v1/cases/'+d['case_id']).json()['understood']['semantic']['exposure']['credential']=='YES'
 assert c.post('/api/v1/check',json={'situation':'Tôi cần kiểm tra','exposure_answers':{'credential':'SAFE'}}).status_code==422
 assert c.post('/api/v1/check',json={'situation':'Tôi cần kiểm tra','exposure_answers':{'secret':'123456'}}).status_code==422

def test_quoted_warning_not_active_but_caller_quote_active():
 assert interpret('Trang hướng dẫn cảnh báo: “Kẻ xấu yêu cầu gửi OTP”.')['credential_operation']=='DENIED_OR_QUOTED'
 assert interpret('Người gọi nói “hãy gửi OTP cho họ”.')['credential_operation']=='DISCLOSE_TO_CONTACT'

@pytest.mark.parametrize('text',[
 'Nếu tôi đã gửi OTP cho người gọi thì nên làm gì?',
 'Bạn tôi đã gửi OTP cho người gọi. Tôi chỉ đang đọc lại câu chuyện đó.',
])
def test_reference_only_requests_clarification(text):
 r=decide(text)
 assert r.action_class=='PAUSE_VERIFY'
 assert r.understood['semantic']['unsupported_input']
 assert r.understood['semantic']['exposure']['credential']=='UNKNOWN'
