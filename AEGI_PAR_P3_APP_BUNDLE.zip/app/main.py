from __future__ import annotations

import os
import time
import uuid
from contextlib import asynccontextmanager
from collections import defaultdict, deque
from dataclasses import asdict
from pathlib import Path
from typing import Literal

from fastapi import FastAPI, File, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from starlette.middleware.trustedhost import TrustedHostMiddleware
from starlette.responses import PlainTextResponse
from pydantic import BaseModel, Field, field_validator

from .acquisition import AcquisitionError, inspect_image
from .engine import RELEASE_VERSION, SOURCES, decide
from .store import (
    DEFAULT_TTL_HOURS,
    cleanup_expired,
    delete_case,
    get_attachment,
    get_case,
    init_store,
    put_attachment,
    put_case,
    ready,
)


class ExposureAnswers(BaseModel):
    model_config = {"extra": "forbid"}
    payment: Literal["YES", "NO", "UNKNOWN"] = "UNKNOWN"
    credential: Literal["YES", "NO", "UNKNOWN"] = "UNKNOWN"
    control: Literal["YES", "NO", "UNKNOWN"] = "UNKNOWN"


class CheckRequest(BaseModel):
    exposure_answers: ExposureAnswers = Field(default_factory=ExposureAnswers)
    situation: str = Field(min_length=3, max_length=4000)
    phone: str | None = Field(default=None, max_length=32)
    account: str | None = Field(default=None, max_length=64)
    action_state: Literal[
        "UNKNOWN",
        "NOT_STARTED",
        "MOBILISED_NOT_TRANSFERRED",
        "ALREADY_TRANSFERRED",
    ] = "UNKNOWN"
    attachment_tokens: list[str] = Field(default_factory=list, max_length=3)

    @field_validator("situation")
    @classmethod
    def strip_situation(cls, value: str) -> str:
        return value.strip()

    @field_validator("phone", "account")
    @classmethod
    def strip_optional(cls, value: str | None) -> str | None:
        if value is None:
            return None
        value = value.strip()
        return value or None

    @field_validator("attachment_tokens")
    @classmethod
    def validate_tokens(cls, values: list[str]) -> list[str]:
        out: list[str] = []
        for value in values:
            if not value.startswith("att_") or len(value) > 64:
                raise ValueError("Invalid attachment token")
            if value not in out:
                out.append(value)
        return out


DEMO_PROFILES = [
    {
        "id": "hero1_unknown_identifier",
        "label": "Hero 1 · Unknown-Identifier Protection",
        "thesis": "NO_MATCH không được suy ra SAFE khi context/procedure cho thấy hành động hậu quả cao.",
        "situation": "Người gọi tự xưng Công an nói tài khoản của tôi liên quan vụ án. Họ yêu cầu tôi tất toán sổ tiết kiệm rồi chuyển 300 triệu đồng sang một ‘tài khoản kiểm tra’ để xác minh. Tôi đã tất toán nhưng chưa chuyển tiền.",
        "phone": "0909123456",
        "account": "123456789012",
        "action_state": "MOBILISED_NOT_TRANSFERRED",
    },
    {
        "id": "hero2_legitimate_unfamiliar",
        "label": "Hero 2 · Legitimate Unfamiliar",
        "thesis": "Tình huống lạ nhưng route khớp procedure fixture hiện hành không nên bị hard-stop vô lý.",
        "situation": "Tôi nhận tin nhắn nhắc đóng học phí từ một số chưa lưu. Nội dung yêu cầu chuyển học phí kỳ này vào tài khoản thu học phí của Trường Minh An (DEMO). Tôi đã tự mở cổng chính thức của trường để đối chiếu khoản thu và tài khoản nhận. Tôi chưa thanh toán và muốn kiểm tra trước.",
        "phone": "0900000202",
        "account": "999900001234567890",
        "action_state": "NOT_STARTED",
    },
    {
        "id": "hero3_reviewed_memory",
        "label": "Hero 3 · Reviewed Memory",
        "thesis": "Reviewed memory có thể đóng góp protective signal cho biến thể mới mà không biến pattern similarity thành fraud verdict.",
        "situation": "Tôi chưa từng mua của người bán này. Người bán mới bảo rời sàn sang Zalo riêng và chuyển khoản đặt cọc vào tài khoản cá nhân để giữ hàng 10 phút. Tôi chưa chuyển tiền.",
        "phone": "0900000303",
        "account": "777700001111222233",
        "action_state": "NOT_STARTED",
    },
]

@asynccontextmanager
async def lifespan(_: FastAPI):
    init_store()
    cleanup_expired()
    yield


app = FastAPI(
    title="AEGI PAR Demo P3",
    version="0.4.2-rc4",
    docs_url=None,
    redoc_url=None,
    openapi_url=None,
    lifespan=lifespan,
)

PUBLIC_TRIAL = os.getenv("PAR_PUBLIC_TRIAL", "0") == "1"
PUBLIC_HTTPS = os.getenv("PAR_PUBLIC_HTTPS", "0") == "1"
ALLOWED_HOSTS = [x.strip() for x in os.getenv(
    "PAR_ALLOWED_HOSTS",
    "localhost,127.0.0.1,testserver,*.up.railway.app",
).split(",") if x.strip()]
DEPLOYMENT_REF = os.getenv("RAILWAY_DEPLOYMENT_ID") or os.getenv("PAR_DEPLOYMENT_REF") or "LOCAL"

STATIC = Path(__file__).parent / "static"
app.add_middleware(TrustedHostMiddleware, allowed_hosts=ALLOWED_HOSTS)
app.mount("/static", StaticFiles(directory=STATIC), name="static")
init_store()
cleanup_expired()

_REQUESTS: dict[str, deque[float]] = defaultdict(deque)
RATE_WINDOW_SECONDS = 60
RATE_LIMIT = int(os.getenv("PAR_RATE_LIMIT_PER_MINUTE", "120"))


@app.middleware("http")
async def security_and_rate_headers(request: Request, call_next):
    now = time.monotonic()
    client = request.client.host if request.client else "unknown"
    bucket = _REQUESTS[client]
    while bucket and now - bucket[0] > RATE_WINDOW_SECONDS:
        bucket.popleft()
    if len(bucket) >= RATE_LIMIT:
        return JSONResponse({"detail": "Demo rate limit exceeded"}, status_code=429)
    bucket.append(now)

    request_id = request.headers.get("X-Request-ID") or f"req_{uuid.uuid4().hex[:16]}"
    response = await call_next(request)
    response.headers["X-Request-ID"] = request_id
    response.headers["X-PAR-Release"] = RELEASE_VERSION
    response.headers["Cache-Control"] = "no-store"
    response.headers["Pragma"] = "no-cache"
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "no-referrer"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=(), payment=()"
    response.headers["Cross-Origin-Opener-Policy"] = "same-origin"
    response.headers["Cross-Origin-Resource-Policy"] = "same-origin"
    response.headers["X-Robots-Tag"] = "noindex, nofollow, noarchive"
    if PUBLIC_HTTPS:
        response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    response.headers["Content-Security-Policy"] = (
        "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data: blob:; "
        "connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'"
    )
    return response


@app.get("/robots.txt", response_class=PlainTextResponse)
def robots() -> str:
    return "User-agent: *\nDisallow: /\n"


@app.get("/api/v1/about")
def about() -> dict:
    return {
        "release": RELEASE_VERSION,
        "mode": "PUBLIC_TRIAL" if PUBLIC_TRIAL else "LOCAL_OR_PREVIEW",
        "decision_authority": "DETERMINISTIC_POLICY",
        "model_authority": "NONE",
        "external_decision_io": False,
        "claim_boundary": [
            "Protective action is not a fraud verdict.",
            "No private bank/telco/platform/law-enforcement integration is present.",
            "Hero 2 and Hero 3 use labelled synthetic/demo fixtures.",
            "QR decode is an observation, not a safety verdict.",
            "Raw situation text and raw image bytes are not persisted.",
            "Language interpretation uses bounded rules; unknown context requires clarification.",
            "This is a remediation candidate, not an independently validated release.",
        ],
    }


@app.get("/")
def home() -> FileResponse:
    return FileResponse(STATIC / "index.html")


@app.get("/api/v1/health")
def health() -> dict:
    return {
        "status": "ok",
        "release": RELEASE_VERSION,
        "mode": "P3_PUBLIC_TRIAL_CANDIDATE",
        "public_trial": PUBLIC_TRIAL,
        "public_https_expected": PUBLIC_HTTPS,
        "deployment_ref": DEPLOYMENT_REF,
        "allowed_hosts": ALLOWED_HOSTS,
        "network_dependency": "NONE_FOR_DECISION_PATH",
        "persistence": "SQLITE_TTL_METADATA_ONLY",
    }


@app.get("/api/v1/readyz")
def readyz() -> JSONResponse:
    state = ready()
    code = 200 if state.get("ready") else 503
    return JSONResponse({"release": RELEASE_VERSION, **state}, status_code=code)


@app.get("/api/v1/demo/profiles")
def demo_profiles() -> dict:
    return {"release": RELEASE_VERSION, "profiles": DEMO_PROFILES}


@app.post("/api/v1/uploads/image")
async def upload_image(file: UploadFile = File(...)) -> dict:
    try:
        token, metadata = await inspect_image(file)
    except AcquisitionError as exc:
        raise HTTPException(400, str(exc)) from exc
    put_attachment(token, metadata)
    return {
        "release": RELEASE_VERSION,
        "attachment": metadata,
        "ttl_hours": DEFAULT_TTL_HOURS,
        "privacy": "RAW_IMAGE_DISCARDED_AFTER_INSPECTION",
    }


@app.post("/api/v1/check")
def check(payload: CheckRequest) -> dict:
    attachments = []
    for token in payload.attachment_tokens:
        metadata = get_attachment(token)
        if metadata is None:
            raise HTTPException(410, f"Attachment expired or unavailable: {token}")
        attachments.append(metadata)

    result = decide(
        payload.situation,
        phone=payload.phone,
        account=payload.account,
        action_state=payload.action_state,
        attachments=attachments,
        exposure_answers=payload.exposure_answers.model_dump(),
    )
    data = asdict(result)
    put_case(result.case_id, data)
    return {
        **data,
        "persistence": {
            "ttl_hours": DEFAULT_TTL_HOURS,
            "raw_input_persisted": False,
            "raw_image_persisted": False,
            "delete_endpoint": f"/api/v1/cases/{result.case_id}",
        },
    }


@app.get("/api/v1/cases/{case_id}")
def case_get(case_id: str) -> dict:
    case = get_case(case_id)
    if case is None:
        raise HTTPException(404, "Case not found or expired")
    return case


@app.delete("/api/v1/cases/{case_id}")
def case_delete(case_id: str) -> dict:
    deleted = delete_case(case_id)
    return {"status": "deleted" if deleted else "not_found", "case_id": case_id, "release": RELEASE_VERSION}


@app.get("/api/v1/cases/{case_id}/evidence")
def get_evidence(case_id: str) -> dict:
    case = get_case(case_id)
    if case is None:
        raise HTTPException(404, "Case not found or expired")
    source_ids = {e.get("source_id") for e in case["evidence"] if e.get("source_id")}
    source_records = [s for s in SOURCES if s["source_id"] in source_ids]
    return {
        "case_id": case_id,
        "release": RELEASE_VERSION,
        "evidence": case["evidence"],
        "sources": source_records,
        "trace": case["trace"],
        "capability": case["capability"],
        "performance": case["performance"],
        "persistence": case.get("persistence"),
    }
