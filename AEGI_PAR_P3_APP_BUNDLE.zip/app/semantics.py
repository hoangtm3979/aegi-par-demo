"""Bounded clause/event interpretation. All assertions remain unverified self-report.
Offsets index accent-folded redacted input. Not a general NLU or identity verifier.
"""
import re
import unicodedata
VERSION = 'PAR-SEMANTIC-CONTRACT-v0.3'

def fold(text):
    return ''.join(c for c in unicodedata.normalize('NFD', text.casefold().replace('đ','d')) if unicodedata.category(c) != 'Mn')

def has(pattern, text): return bool(re.search(pattern, text))

CREDENTIAL = r'\botp\b|ma xac thuc|ma dung mot lan|(?:sau|6) chu so|verification code|ma.*sms|mat khau|password|passcode|(?:gui|doc|chia se|dua)\s+ma\b(?!\s+truy cap may)|\bma\b(?!\s+truy cap may).{0,28}(?:gui|doc|chia se|dua|nhan cho).{0,28}(?:nguoi|ong|ba|ho|ben)'
REMOTE = r'anydesk|teamviewer|chia se man hinh|dieu khien (?:tu xa|thiet bi|may|dien thoai|laptop)|ma truy cap may|re chuot|remote access|screen sharing'
DISCLOSE = r'cung cap|gui|doc|chia se|tiet lo|dua|cho biet|nhan cho|share|send|give'
CONTACT = r'nguoi (?:goi|lien he|ho tro|ta|la)|ong goi dien|ba goi dien|ben ho tro|cho ho|cho ben|cho nguoi|yeu cau|to (?:them|caller)|caller'
NEGATION = r'\b(?:khong|chua|never|do not|tu choi)\b'


def clauses(value):
    """Split punctuation/contrast outside quotations; keep exact normalized offsets."""
    quote = None; start = 0; spans = []
    for i,c in enumerate(value):
        if c in '“”"':
            if quote is None: quote=c
            elif (quote=='“' and c=='”') or c==quote: quote=None
        if quote is None and c in '.!?;\n':
            spans.append((start,i)); start=i+1
    spans.append((start,len(value)))
    for a,b in spans:
        segment=value[a:b]; cursor=0
        for m in list(re.finditer(r'\b(?:nhung|tuy nhien|but|however)\b',segment))+[None]:
            end=m.start() if m else len(segment)
            raw=segment[cursor:end]; left=len(raw)-len(raw.lstrip()); right=len(raw.rstrip())
            if raw.strip(): yield raw.strip(),a+cursor+left,a+cursor+right
            cursor=m.end() if m else end


def interpret(text):
    value=fold(text); events=[]; cred=[]; remote=[]; pressure=[]; active=[]
    exp={'payment':[], 'credential':[], 'control':[]}; concern=False; no_concern=False
    institution='UNKNOWN'; channel='UNKNOWN'; domain='GENERAL'; actor=None; purpose=None
    actions=[]; context=[]
    def event(field,state,c,a,b,mode,polarity='AFFIRMED',who='USER_OR_CONTACT_UNRESOLVED',operation=None,recipient='UNKNOWN'):
        events.append(dict(field=field,state=state,start=a,end=b,origin='USER_DESCRIPTION_NOT_VERIFIED',coordinate_space='FOLDED_REDACTED_TEXT',actor=who,operation=operation or field,recipient=recipient,polarity=polarity,time_scope=mode))
    for c,a,b in clauses(value):
        reference=has(r'canh bao:|vi du(?: canh bao)?[: ]|bai hoc.*:|dong ghi chu.*:|he thong:|trang huong dan canh bao',c)
        hypothetical=has(r'^neu\b|^gia su\b',c)
        historical=has(r'tung hoc|truoc day|nam ngoai',c) and not has(r'nay|hien tai|bay gio',c)
        third=has(r'^(?:ban toi|me toi|anh toi|chi toi|nan nhan)\b',c)
        mode='QUOTED_REFERENCE' if reference else 'HYPOTHETICAL' if hypothetical else 'HISTORICAL' if historical else 'THIRD_PARTY' if third else 'CURRENT_REPORTED'
        excluded=mode!='CURRENT_REPORTED'
        # Negation is scoped to the relevant operation, not any negative word in the sentence.
        denied=has(NEGATION+r'[^,;.!?]{0,45}(?:'+DISCLOSE+r'|yeu cau|chia se|dieu khien|cho phep|cai)',c)
        who='USER' if has(r'^toi\b|myself',c) else 'CONTACT' if has(CONTACT,c) else 'UNKNOWN'
        if has(CREDENTIAL,c):
            if excluded or denied: state='DENIED_OR_QUOTED'
            elif has(DISCLOSE,c) and has(CONTACT,c): state='DISCLOSE_TO_CONTACT'
            elif has(r'tu (?:nhap|go|xac nhan)',c) and has(r'chinh thuc|tu mo|do toi mo',c): state='SELF_ENTRY_REPORTED'
            else: state='UNKNOWN'
            cred.append(state); event('credential_operation',state,c,a,b,mode,'NEGATED' if denied else 'AFFIRMED',who,'CREDENTIAL','CONTACT' if state=='DISCLOSE_TO_CONTACT' else 'SELF_APP' if state=='SELF_ENTRY_REPORTED' else 'UNKNOWN')
            if not excluded:
                if denied and has(r'(?:toi )?(?:chua|khong).{0,20}(?:'+DISCLOSE+r')',c): exp['credential'].append('NO')
                elif state=='DISCLOSE_TO_CONTACT' and (has(r'\b(?:da|vua|already)\b.{0,28}(?:'+DISCLOSE+r')',c) or has(r'(?:'+DISCLOSE+r').{0,28}\b(?:roi|already)\b',c)): exp['credential'].append('YES')
        if has(REMOTE+r'|(?:tu )?cai (?:app|ung dung)',c):
            if excluded or denied: state='DENIED_OR_QUOTED'
            elif has(CONTACT+r'|ho thao tac',c) and has(REMOTE,c): state='REQUESTED_CONTROL'
            elif 'tu cai' in c and 'chinh thuc' in c and not has(REMOTE,c): state='SELF_INSTALL_REPORTED'
            else: state='UNKNOWN'
            remote.append(state); event('remote_operation',state,c,a,b,mode,'NEGATED' if denied else 'AFFIRMED',who,'DEVICE_CONTROL','CONTACT' if state=='REQUESTED_CONTROL' else 'UNKNOWN')
            if not excluded:
                if (has(r'\b(?:da|vua)\b.{0,40}(?:gui ma truy cap|cho phep|cap quyen|chia se man hinh|cho .{0,20}dieu khien)',c) or has(r'(?:cho .{0,20}dieu khien|dua ma .{0,20}dieu khien).{0,20}\broi\b',c)) and not denied: exp['control'].append('YES')
                elif has(r'chua.{0,28}(?:cap quyen|cho phep|chia se|dieu khien)',c): exp['control'].append('NO')
        if not excluded and has(r'(?:ho|nguoi goi|nguoi ta|nguoi ho tro).{0,18}da (?:dang nhap|dieu khien)|may.*dang bi dieu khien|(?:toi|tui|em).{0,18}(?:da )?cho (?:nguoi ta|ho|nguoi ho tro).{0,18}dieu khien.{0,12}(?:roi|rồi)?',c):
            exp['control'].append('YES'); event('control_exposure','YES',c,a,b,mode,who='CONTACT',operation='ACCOUNT_OR_DEVICE_ACCESS')
        if has(r'bi mat(?! tien)|khong duoc noi|de doa|bat giu|phong toa|\bngay\b|hom nay|\bkhan\b|10 phut|deadline|urgent|secret',c):
            denied_pressure=has(r'khong (?:co )?(?:de doa|ep buoc)|no threat',c)
            if excluded or denied_pressure: state='DENIED_OR_QUOTED'
            elif has(r'(?:yeu cau|bao|bat|ep|doi).*?(?:bi mat(?! tien)|khong duoc noi)|\bde doa\b|threaten|keep.*secret',c): state='COERCIVE'
            elif has(r'\bhan\b|deadline',c): state='ORDINARY_DEADLINE_REPORTED'
            else: state='AMBIGUOUS'
            pressure.append(state); event('pressure_kind',state,c,a,b,mode,'NEGATED' if denied_pressure else 'AFFIRMED',who)
        if excluded: continue
        before=(institution,channel,domain,purpose,tuple(actions))
        active.append(c)
        for m in re.finditer(r'(?:(?:(?:toi|tui|em) )?(?:da|vua) (?:chuyen (?:tien|khoan)|thanh toan|ck)|(?:(?:toi|tui|em) )?chua (?:chuyen|thanh toan|ck))',c):
            state='NO' if 'chua' in m.group() else 'YES'
            # A conditional embedded in a clause is not a completed action.
            if not has(r'neu.{0,20}$',c[:m.start()]):
                exp['payment'].append(state); event('payment_exposure',state,c,a+m.start(),a+m.end(),mode,who='USER')
        for m in re.finditer(r'bi lua|mat tien|lo ma|lo thong tin|lo credential|phat hien.*(?:khac|sai)',c):
            neg=has(NEGATION+r'.{0,28}$',c[:m.start()])
            concern |= not neg; no_concern |= neg
        no_concern |= has(r'khong (?:co )?(?:dau hieu bat thuong|nghi ngo)',c)
        # Current school after an explicit transfer replaces historical school mention.
        current=c.split('nay')[-1] if 'nay' in c and 'tung hoc' in c else c
        if has(r'truong minh an',current): institution='MINH_AN_DEMO'
        elif has(r'truong\s+(?!hop\b|de\b|va\b|la\b|qua\b|noi\b)',current): institution='OTHER_OR_UNRESOLVED'
        portal=has(r'cong (?:thong tin )?chinh thuc|tu mo cong|tren cong|qua cong',c)
        claimant=has(r'nguoi goi.*(?:noi|bao)|ho noi|tu xung.*noi',c)
        negportal=has(r'chua tu mo|khong tu mo|chua.*(?:kiem tra|doi chieu).*cong',c)
        if portal and not claimant and not negportal: channel='SCHOOL_PORTAL_REPORTED'
        elif portal and channel=='UNKNOWN': channel='CLAIMANT_REPORTED' if claimant else 'UNKNOWN'
        elif 'email' in c and channel=='UNKNOWN': channel='SCHOOL_EMAIL_REPORTED'
        elif has(r'nhom lop|tin nhan lop',c) and channel=='UNKNOWN': channel='CLASS_MESSAGE_REPORTED'
        if has(r'tu xung.{0,25}(?:cong an|canh sat)|(?:cong an|canh sat).*(?:yeu cau|bao toi)|police',c): domain='PUBLIC_AUTHORITY'; actor='Cơ quan Công an (người liên hệ tự xưng)'
        elif domain!='PUBLIC_AUTHORITY' and has(r'hoc phi|tuition',c): domain='EDUCATION'; actor='Đơn vị giáo dục được người dùng nêu'
        elif domain=='GENERAL' and has(r'nguoi ban|shop|san|dat coc|marketplace',c): domain='ECOMMERCE'; actor='Đối tác thương mại được người dùng nêu'
        elif domain=='GENERAL' and has(r'tu xung.*ngan hang',c): domain='FINANCE'; actor='Ngân hàng (người liên hệ tự xưng)'
        if has(r'chuyen tien|chuyen khoan|tai khoan kiem tra|dat coc|thanh toan|hoc phi',c): actions.append('TRANSFER_MONEY')
        if has(r'hoc phi|tuition',c): actions.append('TRANSFER_TUITION'); purpose=purpose or 'Thanh toán học phí'
        if has(r'tat toan|rut tiet kiem|dao han so',c): actions.append('BREAK_TERM_DEPOSIT')
        if has(r'xac minh|kiem tra nguon tien|kiem tra tai khoan',c) and not has(r'khong.*xac minh',c): purpose='Xác minh/kiểm tra'
        if has(r'dat coc|giu hang',c) and purpose is None: purpose='Đặt cọc/giữ hàng'
        if has(r'ngoai san|roi san|zalo rieng|telegram|chuyen rieng',c): context.append('OFF_PLATFORM')
        if has(r'nguoi ban moi|shop moi|chua tung mua|seller moi',c): context.append('NEW_SELLER')
        after=(institution,channel,domain,purpose,tuple(actions))
        for field,old,new in zip(('institution','channel','domain','declared_purpose','requested_actions'),before,after):
            if old!=new:event(field,list(new) if isinstance(new,tuple) else new,c,a,b,mode,who=who)
    # Bounded cross-clause co-reference: a current request to send a code followed by an explicit
    # "chưa gửi gì cho họ/người/bên" denial is treated as no credential disclosure.
    # This does not turn a mere request into exposure and does not cross quoted/hypothetical modes.
    if 'DISCLOSE_TO_CONTACT' in cred and not exp['credential'] and has(r'\bchua gui gi cho (?:ho|nguoi|ben)\b', value):
        exp['credential'].append('NO')
    def merge(values,harm,ordinary):
        if harm in values:return harm
        if any(v in ('UNKNOWN','AMBIGUOUS') for v in values):return 'UNKNOWN'
        return next((v for v in ordinary if v in values),'NONE')
    active_understanding = bool(actions or any(v not in ('DENIED_OR_QUOTED','NONE') for v in cred+remote+pressure))
    exposure={k:('CONFLICT' if len(set(v))>1 else v[0] if v else 'UNKNOWN') for k,v in exp.items()}
    credential=merge(cred,'DISCLOSE_TO_CONTACT',['SELF_ENTRY_REPORTED','DENIED_OR_QUOTED'])
    control=merge(remote,'REQUESTED_CONTROL',['SELF_INSTALL_REPORTED','DENIED_OR_QUOTED'])
    pres=merge(pressure,'COERCIVE',['ORDINARY_DEADLINE_REPORTED','DENIED_OR_QUOTED'])
    if credential=='DISCLOSE_TO_CONTACT':actions.append('DISCLOSE_OTP')
    if control=='REQUESTED_CONTROL':actions.append('INSTALL_OR_REMOTE_ACCESS')
    if pres in ('COERCIVE','UNKNOWN','ORDINARY_DEADLINE_REPORTED'):context.append('URGENCY')
    if 'TRANSFER_MONEY' in actions:context.append('TRANSFER_MONEY')
    return dict(version=VERSION,credential_operation=credential,remote_operation=control,pressure_kind=pres,institution=institution,channel=channel,
        exposure=exposure,credential_compromise_reported='YES' in exp['credential'],control_compromise_reported='YES' in exp['control'],concern_reported=concern,no_concern_reported=no_concern,
        observations=events,trust_basis='USER_REPORTED_NOT_INDEPENDENTLY_VERIFIED',coverage='BOUNDED_RULES_UNKNOWN_OUTSIDE_SUPPORTED_EXPRESSIONS',
        domain=domain,claimed_identity=actor,requested_actions=list(dict.fromkeys(actions)),declared_purpose=purpose,context_signals=list(dict.fromkeys(context)),
        interpretation_status='PARTIAL' if any(v=='UNKNOWN' for v in (credential,control,pres)) or not active_understanding else 'BOUNDED_SUPPORTED',
        unsupported_input=not active_understanding,clarifications=[])


def enrich(text,compiled):
    sem=interpret(text); out=dict(compiled)
    for k in ('domain','claimed_identity','requested_actions','declared_purpose','context_signals'):out[k]=sem[k]
    out['semantic']=sem
    out['pressure_cues']=['URGENCY_OR_AUTHORITY_PRESSURE'] if 'URGENCY' in sem['context_signals'] else []
    out['high_consequence']=bool(out['requested_actions']) or any(sem[f] not in ('NONE','DENIED_OR_QUOTED') for f in ('credential_operation','remote_operation'))
    # Only an explicitly supplied legacy state can contribute payment evidence.
    legacy=compiled.get('explicit_action_state')
    value='YES' if legacy=='ALREADY_TRANSFERRED' else 'NO' if legacy in ('NOT_STARTED','MOBILISED_NOT_TRANSFERRED') else 'UNKNOWN'
    if value!='UNKNOWN':
        old=sem['exposure']['payment'];sem['exposure']['payment']=value if old=='UNKNOWN' else old if old==value else 'CONFLICT'
    out['action_state']='ALREADY_TRANSFERRED' if sem['exposure']['payment']=='YES' else 'NOT_STARTED' if sem['exposure']['payment']=='NO' else 'UNKNOWN'
    apply_answers(out,{})
    return out


def apply_answers(compiled,answers):
    """Typed self-report answers cannot erase affirmative exposures or hazards."""
    sem=compiled['semantic']; conflicts=[]
    for key,value in answers.items():
        if key not in ('payment','credential','control') or value not in ('YES','NO','UNKNOWN'):raise ValueError('Invalid exposure answer')
        if value=='UNKNOWN':continue
        old=sem['exposure'][key]
        sem['exposure'][key]=value if old=='UNKNOWN' else old if old==value else 'CONFLICT'
        if sem['exposure'][key]=='CONFLICT':conflicts.append(key)
        if value=='YES' and key in ('credential','control'):sem[key+'_compromise_reported']=True
    sem['answer_origin']='USER_SELF_REPORT_NOT_VERIFIED' if answers else 'NOT_ANSWERED'
    sem['answer_conflicts']=conflicts
    payment=sem['exposure']['payment']
    compiled['action_state']='ALREADY_TRANSFERRED' if payment=='YES' else 'NOT_STARTED' if payment=='NO' else 'UNKNOWN'
    q=[]
    if any(v in ('UNKNOWN','CONFLICT') for v in sem['exposure'].values()):
        q.append({'id':'exposure','prompt':'Bạn đã làm gì? Chọn riêng từng mục; không nhập mã hoặc mật khẩu.', 'fields': [{'key':k,'label':label,'value':sem['exposure'][k]} for k,label in [('payment','Đã chuyển tiền'),('credential','Đã đọc/gửi mã hoặc mật khẩu cho người khác'),('control','Đã cho người khác truy cập tài khoản hoặc điều khiển thiết bị')]],'options':['UNKNOWN','NO','YES']})
    if sem['unsupported_input'] or sem['interpretation_status']=='PARTIAL':q.append({'id':'request_context','prompt':'Ai đang yêu cầu bạn làm gì? Hãy bổ sung vào mô tả, phân biệt việc đã làm với ví dụ hoặc điều chưa xảy ra.','kind':'EDIT_DESCRIPTION'})
    sem['clarifications']=q[:2]
    return compiled


def safety_flags(compiled):
    sem=compiled.get('semantic')
    if not sem or sem.get('version')!=VERSION:return dict(hazard=False,ambiguous=True,compromised=False,concern=False,legacy=True)
    return dict(hazard=sem['credential_operation']=='DISCLOSE_TO_CONTACT' or sem['remote_operation']=='REQUESTED_CONTROL' or sem['pressure_kind']=='COERCIVE',
        ambiguous=sem['unsupported_input'] or any(sem[x]=='UNKNOWN' for x in ('credential_operation','remote_operation','pressure_kind')) or 'CONFLICT' in sem['exposure'].values(),
        compromised=sem['credential_compromise_reported'] or sem['control_compromise_reported'],concern=sem['concern_reported'],legacy=False)
