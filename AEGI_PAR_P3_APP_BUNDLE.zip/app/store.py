from __future__ import annotations

import json
import os
import sqlite3
import threading
import time
from pathlib import Path
from typing import Any

DEFAULT_TTL_HOURS = int(os.getenv("PAR_CASE_TTL_HOURS", "24"))
STATE_DIR = Path(os.getenv("PAR_STATE_DIR", "/tmp/aegi-par-p3"))
DB_PATH = STATE_DIR / "par_demo.sqlite3"
_LOCK = threading.RLock()


def _connect() -> sqlite3.Connection:
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH, timeout=5.0)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    return conn


def init_store() -> None:
    with _LOCK, _connect() as conn:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS cases (
              case_id TEXT PRIMARY KEY,
              created_at INTEGER NOT NULL,
              expires_at INTEGER NOT NULL,
              result_json TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS attachments (
              token TEXT PRIMARY KEY,
              created_at INTEGER NOT NULL,
              expires_at INTEGER NOT NULL,
              metadata_json TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_cases_expires ON cases(expires_at);
            CREATE INDEX IF NOT EXISTS idx_attachments_expires ON attachments(expires_at);
            """
        )
        conn.commit()


def _expiry(now: int | None = None) -> tuple[int, int]:
    current = int(now or time.time())
    return current, current + DEFAULT_TTL_HOURS * 3600


def cleanup_expired(now: int | None = None) -> dict[str, int]:
    current = int(now or time.time())
    with _LOCK, _connect() as conn:
        c1 = conn.execute("DELETE FROM cases WHERE expires_at <= ?", (current,)).rowcount
        c2 = conn.execute("DELETE FROM attachments WHERE expires_at <= ?", (current,)).rowcount
        conn.commit()
    return {"cases": c1, "attachments": c2}


def put_case(case_id: str, result: dict[str, Any]) -> None:
    created, expires = _expiry()
    payload = json.dumps(result, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    with _LOCK, _connect() as conn:
        conn.execute(
            "INSERT OR REPLACE INTO cases(case_id,created_at,expires_at,result_json) VALUES(?,?,?,?)",
            (case_id, created, expires, payload),
        )
        conn.commit()


def get_case(case_id: str) -> dict[str, Any] | None:
    cleanup_expired()
    with _LOCK, _connect() as conn:
        row = conn.execute("SELECT result_json,created_at,expires_at FROM cases WHERE case_id=?", (case_id,)).fetchone()
    if not row:
        return None
    result = json.loads(row["result_json"])
    result["persistence"] = {
        "created_at_epoch": row["created_at"],
        "expires_at_epoch": row["expires_at"],
        "ttl_hours": DEFAULT_TTL_HOURS,
        "raw_input_persisted": False,
    }
    return result


def delete_case(case_id: str) -> bool:
    with _LOCK, _connect() as conn:
        count = conn.execute("DELETE FROM cases WHERE case_id=?", (case_id,)).rowcount
        conn.commit()
    return bool(count)


def put_attachment(token: str, metadata: dict[str, Any]) -> None:
    created, expires = _expiry()
    payload = json.dumps(metadata, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    with _LOCK, _connect() as conn:
        conn.execute(
            "INSERT OR REPLACE INTO attachments(token,created_at,expires_at,metadata_json) VALUES(?,?,?,?)",
            (token, created, expires, payload),
        )
        conn.commit()


def get_attachment(token: str) -> dict[str, Any] | None:
    cleanup_expired()
    with _LOCK, _connect() as conn:
        row = conn.execute("SELECT metadata_json,expires_at FROM attachments WHERE token=?", (token,)).fetchone()
    if not row:
        return None
    data = json.loads(row["metadata_json"])
    data["expires_at_epoch"] = row["expires_at"]
    return data


def ready() -> dict[str, Any]:
    try:
        init_store()
        with _LOCK, _connect() as conn:
            conn.execute("SELECT 1").fetchone()
        return {"ready": True, "db": str(DB_PATH), "ttl_hours": DEFAULT_TTL_HOURS}
    except Exception as exc:  # pragma: no cover - defensive readiness response
        return {"ready": False, "error": exc.__class__.__name__}
