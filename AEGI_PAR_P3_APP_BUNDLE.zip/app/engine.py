from __future__ import annotations

import hashlib
import json
import time
import uuid
from datetime import date
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

from .security import normalize_digits, redact_secrets
from .semantics import enrich, safety_flags, apply_answers, VERSION as SEMANTIC_VERSION
from .guidance import render, VERSION as GUIDANCE_VERSION

RELEASE_VERSION = "PAR-DEMO-P3-v0.4.2-rc4"
POLICY_VERSION = "PAR-PROTECTIVE-POLICY-v0.4-rc4"
RESOLVER_VERSION = "PAR-RISK-CONTEXT-RESOLVER-v0.4-rc4"
DATA_VERSION = "PAR-DEMO-DATA-P2-2026-09-20"
PROCEDURE_VERSION = "PAR-PROCEDURE-PACK-v0.3-rc4"
MEMORY_VERSION = "PAR-REVIEWED-MEMORY-P2-v0.2"

DATA_DIR = Path(__file__).parent / "data"
SOURCES = json.loads((DATA_DIR / "sources.json").read_text(encoding="utf-8"))
PROCEDURES = json.loads((DATA_DIR / "procedures.json").read_text(encoding="utf-8"))
PATTERNS = json.loads((DATA_DIR / "patterns.json").read_text(encoding="utf-8"))
IDENTIFIER_RECORDS = json.loads((DATA_DIR / "identifier_records.json").read_text(encoding="utf-8"))
SOURCE_BY_ID = {s["source_id"]: s for s in SOURCES}


def _validate_fixture_data() -> None:
    source_ids = [s["source_id"] for s in SOURCES]
    if len(source_ids) != len(set(source_ids)):
        raise RuntimeError("Duplicate source_id in demo data")
    known = set(source_ids)
    for procedure in PROCEDURES:
        if procedure["source_id"] not in known:
            raise RuntimeError(f"Procedure source missing: {procedure['source_id']}")
    for record in IDENTIFIER_RECORDS:
        if record["source_id"] not in known:
            raise RuntimeError(f"Identifier source missing: {record['source_id']}")
    for pattern in PATTERNS:
        if pattern.get("status") != "REVIEWED":
            raise RuntimeError("P1 reviewed-memory fixture must have REVIEWED status")


_validate_fixture_data()


@dataclass(frozen=True)
class EvidenceItem:
    evidence_id: str
    kind: str
    state: str
    label: str
    detail: str
    authority: str
    source_id: str | None = None
    limitations: str | None = None
    metadata: dict[str, Any] | None = None


@dataclass(frozen=True)
class DecisionResult:
    case_id: str
    release: str
    concern_level: str
    concern_label: str
    headline: str
    action_class: str
    actions: list[str]
    reasons: list[str]
    unknowns: list[str]
    verification_steps: list[str]
    evidence: list[dict[str, Any]]
    understood: dict[str, Any]
    capability: dict[str, str]
    trace: dict[str, str]
    performance: dict[str, Any]
    redaction: dict[str, Any]
    disclaimer: str
    action_contract: dict[str, Any]


def _ms(start: float) -> float:
    return round((time.perf_counter() - start) * 1000, 3)


def _has(text: str, *terms: str) -> bool:
    folded = text.casefold()
    return any(term.casefold() in folded for term in terms)


def _compile_case(text: str, action_state: str | None) -> dict[str, Any]:
    # One compiler authority; no legacy keyword result survives interpretation.
    return enrich(text, {"explicit_action_state": action_state})


def _identifier_record(kind: str, normalized: str | None) -> dict[str, Any] | None:
    if not normalized:
        return None
    for record in IDENTIFIER_RECORDS:
        if record["kind"] == kind and record["value"] == normalized:
            return record
    return None


def _lookup_identifier(kind: str, value: str | None, *, available: bool = True) -> EvidenceItem:
    normalized = normalize_digits(value) if kind in {"PHONE", "ACCOUNT"} else value
    display = "số điện thoại" if kind == "PHONE" else "số tài khoản"
    if not normalized:
        return EvidenceItem(
            evidence_id=f"EV-{kind}-NA",
            kind=kind,
            state="NOT_APPLICABLE",
            label="Chưa cung cấp",
            detail=f"Chưa có {display} để đối chiếu.",
            authority="DEMO_FIXTURE",
            limitations="Không có dữ liệu đầu vào cho kênh này.",
        )
    if not available:
        return EvidenceItem(
            evidence_id=f"EV-{kind}-UNAVAILABLE",
            kind=kind,
            state="UNAVAILABLE",
            label="Không thể xác minh lúc này",
            detail="Nguồn đối chiếu demo hiện không khả dụng.",
            authority="DEMO_FIXTURE",
            limitations="UNAVAILABLE không được hiểu là NO_MATCH hoặc SAFE.",
        )

    record = _identifier_record(kind, normalized)
    if record:
        return EvidenceItem(
            evidence_id=f"EV-{kind}-VERIFIED-{record['record_id']}",
            kind=kind,
            state=record["state"],
            label=record["label"],
            detail="Identifier khớp một reference được định nghĩa trong procedure fixture của demo.",
            authority=record["authority_class"],
            source_id=record["source_id"],
            limitations=record["limitations"],
        )

    return EvidenceItem(
        evidence_id=f"EV-{kind}-NO-MATCH",
        kind=kind,
        state="NO_MATCH",
        label="Chưa có cảnh báo đã biết trong dữ liệu demo",
        detail="Không tìm thấy adverse match trong bộ dữ liệu demo P1.",
        authority="DEMO_FIXTURE",
        limitations="Kết quả chỉ phản ánh bộ dữ liệu demo, không xác nhận đối tượng an toàn trong thực tế.",
    )


def _official_warning_evidence(compiled: dict[str, Any]) -> list[EvidenceItem]:
    items: list[EvidenceItem] = []
    if compiled["domain"] == "PUBLIC_AUTHORITY" and "TRANSFER_MONEY" in compiled["requested_actions"]:
        src1 = SOURCE_BY_ID["MPS-2026-09-08-25-SCENARIOS"]
        src2 = SOURCE_BY_ID["MPS-2026-04-01-CAOBANG"]
        items.extend([
            EvidenceItem(
                evidence_id="EV-OFFICIAL-SCENARIO-WARNING-001",
                kind="OFFICIAL_SCENARIO_WARNING",
                state="MATCH",
                label="Khớp kịch bản cảnh báo công khai",
                detail="Nguồn Bộ Công an mô tả thủ đoạn mạo danh cơ quan/tổ chức để yêu cầu chuyển tiền với lý do như 'xác minh thông tin'.",
                authority=src1["authority_class"],
                source_id=src1["source_id"],
                limitations=src1["limitations"],
            ),
            EvidenceItem(
                evidence_id="EV-PROCEDURE-COMPARE-001",
                kind="PROCEDURE_COMPARISON",
                state="DEVIATION",
                label="Có điểm không phù hợp với tuyến xác minh độc lập",
                detail="Yêu cầu chuyển tiền để 'xác minh' trùng với ca mạo danh Công an được cảnh báo; protective route là không giao dịch theo yêu cầu đó và xác minh qua kênh chính thức độc lập.",
                authority=src2["authority_class"],
                source_id=src2["source_id"],
                limitations=src2["limitations"],
            ),
        ])
    return items


def _education_procedure_evidence(
    compiled: dict[str, Any],
    account: str | None,
    *,
    procedure_state: str = "CURRENT",
    force_conflict: bool = False,
    decision_date: str | None = None,
    exposure_answers: dict[str, str] | None = None,
) -> list[EvidenceItem]:
    if compiled["domain"] != "EDUCATION" or "TRANSFER_TUITION" not in compiled["requested_actions"]:
        return []

    normalized = normalize_digits(account)
    if force_conflict:
        return [EvidenceItem(
            evidence_id="EV-PROCEDURE-CONFLICTED-001",
            kind="PROCEDURE_COMPARISON",
            state="CONFLICTED",
            label="Nguồn procedure đang mâu thuẫn",
            detail="Hai snapshot demo đưa ra recipient route khác nhau; hệ thống không được suy ra LOW từ trạng thái này.",
            authority="DEMO_AUTHORITY_FIXTURE",
            source_id="DEMO-SCHOOL-PROCEDURE-001",
            limitations="Conflict fixture phục vụ failure/degradation acceptance.",
        )]

    candidates = [p for p in PROCEDURES if p["status"] == procedure_state]
    if not candidates:
        return [EvidenceItem("EV-PROCEDURE-UNAVAILABLE", "PROCEDURE_COMPARISON", "UNAVAILABLE",
                             "Không có snapshot phù hợp", "Không thể đối chiếu procedure.", "DEMO_AUTHORITY_FIXTURE")]
    procedure = candidates[0]
    as_of = date.fromisoformat(decision_date) if decision_date else date.today()
    current = date.fromisoformat(procedure["valid_from"]) <= as_of <= date.fromisoformat(procedure["valid_to"])
    sem = compiled.get("semantic", {})
    institution = sem.get("institution", "UNKNOWN")
    channel = sem.get("channel", "UNKNOWN").removesuffix("_REPORTED")
    # Generic transfer is subsumed by tuition; extra sensitive operations are not approved by recipient match.
    extra = set(compiled["requested_actions"]) - {"TRANSFER_MONEY", *procedure["expected_actions"]}
    if procedure_state == "STALE" or not current:
        state, label = "STALE", "Procedure ngoài thời hạn hiệu lực"
    elif institution == "OTHER_OR_UNRESOLVED":
        state, label = "OUT_OF_SCOPE", "Không xác lập được cùng tổ chức với procedure fixture"
    elif institution != procedure.get("institution_id") or channel not in procedure["allowed_channels"]:
        state, label = "SCOPE_UNKNOWN", "Chưa đủ thông tin về tổ chức hoặc kênh trong phạm vi procedure"
    elif extra or compiled.get("declared_purpose") != "Thanh toán học phí":
        state, label = "PARTIAL_MATCH", "Yêu cầu bổ sung chưa được procedure bao phủ"
    elif normalized in procedure["approved_recipient_accounts"]:
        state, label = "MATCH", "Khớp phạm vi procedure fixture hiện hành"
    else:
        state, label = "DEVIATION", "Recipient route lệch procedure fixture"
    return [EvidenceItem(
        evidence_id="EV-PROCEDURE-SCOPE-001", kind="PROCEDURE_COMPARISON", state=state,
        label=label, detail="Đối chiếu tổ chức, kênh được mô tả, mục đích, recipient và thời hạn trong fixture demo.",
        authority=procedure["authority_class"], source_id=procedure["source_id"],
        limitations="Mô tả kênh là do người dùng cung cấp; không xác minh ownership hay tính hợp lệ ngoài đời.",
        metadata={"procedure_id":procedure["procedure_id"], "catalog_status":procedure["status"], "status": "STALE" if state == "STALE" else procedure["status"], "effective_state": state,
                  "as_of":as_of.isoformat(), "institution_scope":institution,
                  "reported_channel":channel, "uncovered_actions":sorted(extra)},
    )]


def _reviewed_memory_evidence(
    compiled: dict[str, Any],
    *,
    memory_available: bool = True,
    memory_enabled: bool = True,
) -> list[EvidenceItem]:
    if compiled["domain"] != "ECOMMERCE":
        return []
    if not memory_available:
        return [EvidenceItem(
            evidence_id="EV-MEMORY-UNAVAILABLE-001",
            kind="REVIEWED_PATTERN",
            state="UNAVAILABLE",
            label="Reviewed memory hiện không khả dụng",
            detail="Không thể thực hiện pattern retrieval trong lần kiểm tra này.",
            authority="DEMO_FIXTURE",
            limitations="UNAVAILABLE không được diễn giải thành NO_MATCH.",
        )]
    if not memory_enabled:
        return [EvidenceItem(
            evidence_id="EV-MEMORY-DISABLED-001",
            kind="REVIEWED_PATTERN",
            state="NOT_APPLICABLE",
            label="Reviewed memory bị tắt cho baseline",
            detail="Baseline acceptance chạy cùng tình huống nhưng không sử dụng reviewed memory.",
            authority="DEMO_FIXTURE",
            limitations="Dùng để đo contribution của Hero 3.",
        )]

    pattern = PATTERNS[0]
    observed = set(compiled["context_signals"])
    expected = set(pattern["signals"])
    overlap = len(observed & expected) / len(expected) if expected else 0.0
    if overlap >= 0.75:
        return [EvidenceItem(
            evidence_id="EV-MEMORY-SIMILAR-001",
            kind="REVIEWED_PATTERN",
            state="SIMILAR_REVIEWED",
            label="Tương tự reviewed pattern trong bộ nhớ demo",
            detail="Các tín hiệu tình huống có overlap cao với pattern đã qua review: rời nền tảng + chuyển tiền + urgency + người bán mới.",
            authority=pattern["authority_class"],
            source_id="DEMO-REVIEWED-MEMORY-001",
            limitations=pattern["limitations"],
            metadata={"pattern_id": pattern["pattern_id"], "signal_overlap": round(overlap, 3), "status": pattern["status"]},
        )]

    return [EvidenceItem(
        evidence_id="EV-MEMORY-NO-MATCH-001",
        kind="REVIEWED_PATTERN",
        state="NO_MATCH",
        label="Không có reviewed pattern đủ tương tự trong demo",
        detail="Pattern retrieval đã chạy nhưng không đạt threshold demo.",
        authority=pattern["authority_class"],
        source_id="DEMO-REVIEWED-MEMORY-001",
        limitations="NO_MATCH không phải bằng chứng tình huống an toàn.",
        metadata={"pattern_id": pattern["pattern_id"], "signal_overlap": round(overlap, 3), "status": pattern["status"]},
    )]


def _decision_hash(payload: dict[str, Any]) -> str:
    canonical = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def decide(
    situation: str,
    phone: str | None = None,
    account: str | None = None,
    action_state: str | None = None,
    *,
    identifier_source_available: bool = True,
    procedure_state: str = "CURRENT",
    force_procedure_conflict: bool = False,
    reviewed_memory_available: bool = True,
    reviewed_memory_enabled: bool = True,
    attachments: list[dict[str, Any]] | None = None,
    decision_date: str | None = None,
    exposure_answers: dict[str, str] | None = None,
) -> DecisionResult:
    total_start = time.perf_counter()
    stage_ms: dict[str, float] = {}

    s = time.perf_counter()
    redaction = redact_secrets(situation)
    compiled = _compile_case(redaction.text, action_state)
    apply_answers(compiled, exposure_answers or {})
    stage_ms["intake_compile"] = _ms(s)

    # Fast safety path stops at a bounded action class; it does not assert fraud truth.
    s = time.perf_counter()
    if safety_flags(compiled)["compromised"]:
        fast_action = "RECOVER"
    elif compiled["domain"] == "PUBLIC_AUTHORITY" and "TRANSFER_MONEY" in compiled["requested_actions"]:
        fast_action = "PAUSE_VERIFY"
    elif compiled["high_consequence"]:
        fast_action = "PAUSE"
    else:
        fast_action = "CONTINUE_CAUTION"
    stage_ms["fast_policy"] = _ms(s)
    ttfp_ms = round(sum(stage_ms.values()), 3)

    s = time.perf_counter()
    evidence: list[EvidenceItem] = [
        _lookup_identifier("PHONE", phone, available=identifier_source_available),
        _lookup_identifier("ACCOUNT", account, available=identifier_source_available),
    ]
    stage_ms["identifier_lookup"] = _ms(s)

    s = time.perf_counter()
    evidence.extend(_official_warning_evidence(compiled))
    evidence.extend(_education_procedure_evidence(
        compiled,
        account,
        procedure_state=procedure_state,
        force_conflict=force_procedure_conflict,
        decision_date=decision_date,
    ))
    stage_ms["procedure_context"] = _ms(s)

    s = time.perf_counter()
    evidence.extend(_reviewed_memory_evidence(
        compiled,
        memory_available=reviewed_memory_available,
        memory_enabled=reviewed_memory_enabled,
    ))
    stage_ms["reviewed_memory"] = _ms(s)

    s = time.perf_counter()
    attachment_items = attachments or []
    for idx, item in enumerate(attachment_items[:3], start=1):
        state = item.get("state", "ACCEPTED_METADATA_ONLY")
        if state == "QR_DECODED":
            detail = f"QR payload đã được decode cục bộ ({item.get('qr_payload_type','UNKNOWN')}); đây là observation, không phải verdict."
            label = "Đã đọc QR từ ảnh"
            kind = "QR_OBSERVATION"
        else:
            detail = "Ảnh được ghi nhận bằng fingerprint/metadata; P3 không OCR ảnh chung."
            label = "Ảnh đã được tiếp nhận"
            kind = "IMAGE_OBSERVATION"
        evidence.append(EvidenceItem(
            evidence_id=f"EV-ATTACHMENT-{idx:02d}",
            kind=kind,
            state=state,
            label=label,
            detail=detail,
            authority="USER_SUPPLIED_EVIDENCE",
            limitations=item.get("limitations"),
            metadata={
                "sha256": item.get("sha256"),
                "width": item.get("width"),
                "height": item.get("height"),
                "content_type": item.get("content_type"),
                "qr_payload_type": item.get("qr_payload_type"),
                "qr_payload": item.get("qr_payload"),
                "raw_file_persisted": False,
            },
        ))
    stage_ms["attachment_observation"] = _ms(s)

    s = time.perf_counter()
    high_consequence = compiled["high_consequence"]
    state = compiled["action_state"]
    scenario_warning_match = any(e.kind == "OFFICIAL_SCENARIO_WARNING" and e.state == "MATCH" for e in evidence)
    procedure_deviation = any(e.kind == "PROCEDURE_COMPARISON" and e.state == "DEVIATION" for e in evidence)
    procedure_match = any(e.kind == "PROCEDURE_COMPARISON" and e.state == "MATCH" for e in evidence)
    procedure_unreliable = any(e.kind == "PROCEDURE_COMPARISON" and e.state in {"STALE", "CONFLICTED", "UNAVAILABLE", "OUT_OF_SCOPE", "SCOPE_UNKNOWN", "PARTIAL_MATCH", "WITHHELD_FOR_TEST"} for e in evidence)
    reviewed_similar = any(e.kind == "REVIEWED_PATTERN" and e.state == "SIMILAR_REVIEWED" for e in evidence)
    recipient_reference_match = any(e.kind == "ACCOUNT" and e.state == "REFERENCE_MATCH" for e in evidence)

    flags = safety_flags(compiled)
    concern = flags["hazard"] or flags["concern"] or scenario_warning_match or procedure_deviation or reviewed_similar
    completed = state == "ALREADY_TRANSFERRED"
    scoped_match = procedure_match and recipient_reference_match and not procedure_unreliable
    if flags["compromised"] or (completed and concern):
        template = "RECOVER"
    elif completed:
        template = "COMPLETED_RECORD" if scoped_match and not flags["ambiguous"] else "COMPLETED_CHECK"
    elif flags["hazard"] or (high_consequence and (scenario_warning_match or procedure_deviation or reviewed_similar)):
        template = "PREVENT"
    elif flags["ambiguous"] or flags["concern"] or procedure_unreliable:
        template = "PAUSE"
    elif scoped_match:
        template = "LIGHT"
    elif high_consequence:
        template = "PAUSE"
    else:
        template = "GENERAL"
    presentation = render(template)
    concern_level = presentation["concern_level"]
    concern_label = presentation["concern_label"]
    headline = presentation["headline"]
    action_class = presentation["action_class"]
    actions = presentation["actions"]
    stage_ms["deterministic_policy"] = _ms(s)

    reasons: list[str] = []
    if flags["compromised"]:
        reasons.append("Bạn cho biết đã tiết lộ mã hoặc cho người khác truy cập tài khoản/thiết bị; cần xử lý ngay dù chưa chuyển tiền.")
    if flags["hazard"]:
        reasons.append("Mô tả có yêu cầu tiết lộ credential, cấp quyền điều khiển hoặc ép buộc; reference recipient không bao phủ yêu cầu đó.")
    if flags["ambiguous"]:
        reasons.append("PAR chưa hiểu chắc một phần mô tả hoặc có thông tin mâu thuẫn; hãy kiểm tra lại các mục bên dưới.")
    if scenario_warning_match:
        reasons.append("Yêu cầu hiện tại trùng một kịch bản mạo danh/chuyển tiền đã được Bộ Công an cảnh báo công khai.")
    if procedure_deviation:
        reasons.append("Recipient/action route lệch khỏi procedure reference đang được dùng cho quyết định bảo vệ.")
    if procedure_match:
        reasons.append("Thông tin được mô tả khớp phạm vi procedure fixture hiện hành; không xác minh tổ chức hoặc giao dịch thật.")
    if reviewed_similar:
        reasons.append("Reviewed memory đóng góp một pattern similarity có provenance; đây là protective signal, không phải fraud verdict.")
    if any(e.state == "NO_MATCH" for e in evidence if e.kind in {"PHONE", "ACCOUNT"}):
        reasons.append("Một hoặc nhiều identifier chưa có adverse match trong dữ liệu demo; điều này không phải bằng chứng an toàn.")
    if procedure_unreliable:
        reasons.append("Procedure chưa đủ độ tin cậy hoặc chưa bao phủ phạm vi yêu cầu; không dùng để hạ mức concern.")
    if compiled["high_consequence"]:
        reasons.append("Hành động được yêu cầu có hậu quả tài chính hoặc quyền kiểm soát khó đảo ngược.")

    unknowns: list[str] = []
    if compiled["claimed_identity"]:
        unknowns.append("Danh tính thực của chủ thể liên hệ chưa được xác minh độc lập.")
    if account and not recipient_reference_match:
        unknowns.append("Chủ tài khoản nhận tiền chưa được xác minh bằng nguồn có thẩm quyền trong demo.")
    if phone:
        unknowns.append("Quan hệ giữa số điện thoại và tổ chức được mô tả/tự xưng chưa được xác minh.")
    if not unknowns:
        unknowns.append("Chưa xác minh độc lập danh tính, yêu cầu và tình trạng tài khoản/thiết bị của bạn. Kết quả này không bảo đảm giao dịch an toàn.")

    verification_steps = presentation["verification_steps"]
    action_contract = presentation["action_contract"]

    evidence_dicts = [asdict(item) for item in evidence]
    decision_payload = {
        "release": RELEASE_VERSION,
        "concern_level": concern_level,
        "action_class": action_class,
        "actions": actions,
        "headline": headline,
        "verification_steps": verification_steps,
        "action_contract": action_contract,
        "reasons": reasons,
        "evidence": evidence_dicts,
        "understood": compiled,
        "policy_version": POLICY_VERSION,
        "resolver_version": RESOLVER_VERSION,
        "data_version": DATA_VERSION,
        "procedure_version": PROCEDURE_VERSION,
        "memory_version": MEMORY_VERSION,
        "attachment_fingerprints": [item.get("sha256") for item in (attachments or [])[:3]],
    }
    decision_hash = _decision_hash(decision_payload)
    total_ms = _ms(total_start)

    capability = {
        "identifier_lookup": "AVAILABLE" if identifier_source_available else "UNAVAILABLE",
        "official_warning": "AVAILABLE",
        "procedure_intelligence": procedure_state if not force_procedure_conflict else "CONFLICTED",
        "reviewed_memory": "DISABLED" if not reviewed_memory_enabled else ("AVAILABLE" if reviewed_memory_available else "UNAVAILABLE"),
        "semantic_interpretation": "BOUNDED_RULES_WITH_UNKNOWNS",
        "image_qr_acquisition": "AVAILABLE_LOCAL_ONLY",
        "generic_image_ocr": "NOT_ENABLED",
        "enforcement_authority": "NOT_GRANTED",
    }
    trace = {
        "release": RELEASE_VERSION,
        "semantic_version": SEMANTIC_VERSION,
        "guidance_version": GUIDANCE_VERSION,
        "policy_version": POLICY_VERSION,
        "resolver_version": RESOLVER_VERSION,
        "data_version": DATA_VERSION,
        "procedure_version": PROCEDURE_VERSION,
        "memory_version": MEMORY_VERSION,
        "decision_hash": decision_hash,
        "attachment_count": str(len((attachments or [])[:3])),
    }
    performance = {
        "ttfp_ms": ttfp_ms,
        "total_ms": total_ms,
        "stage_ms": stage_ms,
        "fast_action_class": fast_action,
        "timing_scope": "LOCAL_PROCESS_ONLY",
    }

    return DecisionResult(
        case_id=f"PAR-{uuid.uuid4().hex[:10].upper()}",
        release=RELEASE_VERSION,
        concern_level=concern_level,
        concern_label=concern_label,
        headline=headline,
        action_class=action_class,
        actions=actions,
        reasons=reasons,
        unknowns=unknowns,
        verification_steps=verification_steps,
        evidence=evidence_dicts,
        understood=compiled,
        capability=capability,
        trace=trace,
        performance=performance,
        redaction={"redacted": bool(redaction.redacted_types), "types": list(redaction.redacted_types)},
        action_contract=action_contract,
        disclaimer=(
            "PAR đưa ra hành động bảo vệ trong phạm vi evidence hiện có; không kết luận một cá nhân/tài khoản là gian lận, "
            "không thay thế cơ quan có thẩm quyền và không tự động thực thi giao dịch."
        ),
    )
