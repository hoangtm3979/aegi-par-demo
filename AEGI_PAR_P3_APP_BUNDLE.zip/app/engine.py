from __future__ import annotations

import hashlib
import json
import time
import uuid
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

from .security import normalize_digits, redact_secrets

RELEASE_VERSION = "PAR-DEMO-P3-v0.4.0"
POLICY_VERSION = "PAR-PROTECTIVE-POLICY-P2-v0.3"
RESOLVER_VERSION = "PAR-RISK-CONTEXT-RESOLVER-P2-v0.3"
DATA_VERSION = "PAR-DEMO-DATA-P2-2026-09-20"
PROCEDURE_VERSION = "PAR-PROCEDURE-PACK-P2-v0.2"
MEMORY_VERSION = "PAR-REVIEWED-MEMORY-P2-v0.2"

DATA_DIR = Path(__file__).parent / "data"
SOURCES = json.loads((DATA_DIR / "sources.json").read_text(encoding="utf-8"))
PROCEDURES = json.loads((DATA_DIR / "procedures.json").read_text(encoding="utf-8"))
PATTERNS = json.loads((DATA_DIR / "patterns.json").read_text(encoding="utf-8"))
IDENTIFIER_RECORDS = json.loads((DATA_DIR / "identifier_records.json").read_text(encoding="utf-8"))
SOURCE_BY_ID = {s["source_id"]: s for s in SOURCES}


def _validate_fixture_data() -> None:
    source_ids = [s["source_id"] for s in SOURCES]
    if len(source_ids) != len(set(source_ids)):
        raise RuntimeError("Duplicate source_id in demo data")
    known = set(source_ids)
    for procedure in PROCEDURES:
        if procedure["source_id"] not in known:
            raise RuntimeError(f"Procedure source missing: {procedure['source_id']}")
    for record in IDENTIFIER_RECORDS:
        if record["source_id"] not in known:
            raise RuntimeError(f"Identifier source missing: {record['source_id']}")
    for pattern in PATTERNS:
        if pattern.get("status") != "REVIEWED":
            raise RuntimeError("P1 reviewed-memory fixture must have REVIEWED status")


_validate_fixture_data()


@dataclass(frozen=True)
class EvidenceItem:
    evidence_id: str
    kind: str
    state: str
    label: str
    detail: str
    authority: str
    source_id: str | None = None
    limitations: str | None = None
    metadata: dict[str, Any] | None = None


@dataclass(frozen=True)
class DecisionResult:
    case_id: str
    release: str
    concern_level: str
    concern_label: str
    headline: str
    action_class: str
    actions: list[str]
    reasons: list[str]
    unknowns: list[str]
    verification_steps: list[str]
    evidence: list[dict[str, Any]]
    understood: dict[str, Any]
    capability: dict[str, str]
    trace: dict[str, str]
    performance: dict[str, Any]
    redaction: dict[str, Any]
    disclaimer: str


def _ms(start: float) -> float:
    return round((time.perf_counter() - start) * 1000, 3)


def _has(text: str, *terms: str) -> bool:
    folded = text.casefold()
    return any(term.casefold() in folded for term in terms)


def _compile_case(text: str, action_state: str | None) -> dict[str, Any]:
    claimed_identity = None
    domain = "GENERAL"
    if _has(text, "công an", "cảnh sát", "police"):
        claimed_identity = "Cơ quan/lực lượng Công an (tự xưng)"
        domain = "PUBLIC_AUTHORITY"
    elif _has(text, "ngân hàng", "bank"):
        claimed_identity = "Ngân hàng/tổ chức tài chính (tự xưng)"
        domain = "FINANCE"
    elif _has(text, "trường", "học phí", "tuition"):
        claimed_identity = "Nhà trường/đơn vị giáo dục (được mô tả)"
        domain = "EDUCATION"
    elif _has(text, "người bán", "shop", "sàn", "đặt cọc", "marketplace"):
        claimed_identity = "Người bán/đối tác thương mại (được mô tả)"
        domain = "ECOMMERCE"

    requested_actions: list[str] = []
    if _has(text, "chuyển tiền", "chuyển khoản", "tài khoản kiểm tra", "đặt cọc", "thanh toán", "học phí"):
        requested_actions.append("TRANSFER_MONEY")
    if _has(text, "học phí", "tuition"):
        requested_actions.append("TRANSFER_TUITION")
    if _has(text, "tất toán", "rút tiết kiệm", "đáo hạn sổ"):
        requested_actions.append("BREAK_TERM_DEPOSIT")
    if _has(text, "otp", "mã xác thực", "mã otp"):
        requested_actions.append("DISCLOSE_OTP")
    if _has(text, "cài app", "cài ứng dụng", "anydesk", "teamviewer", "chia sẻ màn hình"):
        requested_actions.append("INSTALL_OR_REMOTE_ACCESS")

    purpose = None
    if _has(text, "xác minh", "kiểm tra nguồn tiền", "kiểm tra tài khoản"):
        purpose = "Xác minh/kiểm tra"
    elif _has(text, "học phí", "tuition"):
        purpose = "Thanh toán học phí"
    elif _has(text, "đặt cọc", "giữ hàng"):
        purpose = "Đặt cọc/giữ hàng"

    inferred_state = action_state or "UNKNOWN"
    if inferred_state == "UNKNOWN":
        if _has(text, "đã chuyển", "chuyển rồi", "đã thanh toán"):
            inferred_state = "ALREADY_TRANSFERRED"
        elif _has(text, "đã tất toán", "đã rút"):
            inferred_state = "MOBILISED_NOT_TRANSFERRED"
        elif _has(text, "chưa chuyển", "chưa làm", "chưa thực hiện", "chưa thanh toán"):
            inferred_state = "NOT_STARTED"

    pressure_cues: list[str] = []
    if _has(text, "khẩn", "ngay", "bí mật", "không được nói", "đe dọa", "bắt giữ", "phong tỏa", "hôm nay", "giữ hàng 10 phút"):
        pressure_cues.append("URGENCY_OR_AUTHORITY_PRESSURE")

    context_signals: list[str] = []
    if _has(text, "ngoài sàn", "rời sàn", "zalo riêng", "telegram", "chuyển riêng"):
        context_signals.append("OFF_PLATFORM")
    if _has(text, "người bán mới", "shop mới", "chưa từng mua", "seller mới"):
        context_signals.append("NEW_SELLER")
    if pressure_cues:
        context_signals.append("URGENCY")
    if "TRANSFER_MONEY" in requested_actions:
        context_signals.append("TRANSFER_MONEY")

    return {
        "domain": domain,
        "claimed_identity": claimed_identity,
        "requested_actions": list(dict.fromkeys(requested_actions)),
        "declared_purpose": purpose,
        "action_state": inferred_state,
        "pressure_cues": pressure_cues,
        "context_signals": list(dict.fromkeys(context_signals)),
        "high_consequence": any(
            action in requested_actions
            for action in ["TRANSFER_MONEY", "TRANSFER_TUITION", "BREAK_TERM_DEPOSIT", "DISCLOSE_OTP", "INSTALL_OR_REMOTE_ACCESS"]
        ),
    }


def _identifier_record(kind: str, normalized: str | None) -> dict[str, Any] | None:
    if not normalized:
        return None
    for record in IDENTIFIER_RECORDS:
        if record["kind"] == kind and record["value"] == normalized:
            return record
    return None


def _lookup_identifier(kind: str, value: str | None, *, available: bool = True) -> EvidenceItem:
    normalized = normalize_digits(value) if kind in {"PHONE", "ACCOUNT"} else value
    display = "số điện thoại" if kind == "PHONE" else "số tài khoản"
    if not normalized:
        return EvidenceItem(
            evidence_id=f"EV-{kind}-NA",
            kind=kind,
            state="NOT_APPLICABLE",
            label="Chưa cung cấp",
            detail=f"Chưa có {display} để đối chiếu.",
            authority="DEMO_FIXTURE",
            limitations="Không có dữ liệu đầu vào cho kênh này.",
        )
    if not available:
        return EvidenceItem(
            evidence_id=f"EV-{kind}-UNAVAILABLE",
            kind=kind,
            state="UNAVAILABLE",
            label="Không thể xác minh lúc này",
            detail="Nguồn đối chiếu demo hiện không khả dụng.",
            authority="DEMO_FIXTURE",
            limitations="UNAVAILABLE không được hiểu là NO_MATCH hoặc SAFE.",
        )

    record = _identifier_record(kind, normalized)
    if record:
        return EvidenceItem(
            evidence_id=f"EV-{kind}-VERIFIED-{record['record_id']}",
            kind=kind,
            state=record["state"],
            label=record["label"],
            detail="Identifier khớp một reference được định nghĩa trong procedure fixture của demo.",
            authority=record["authority_class"],
            source_id=record["source_id"],
            limitations=record["limitations"],
        )

    return EvidenceItem(
        evidence_id=f"EV-{kind}-NO-MATCH",
        kind=kind,
        state="NO_MATCH",
        label="Chưa có cảnh báo đã biết trong dữ liệu demo",
        detail="Không tìm thấy adverse match trong bộ dữ liệu demo P1.",
        authority="DEMO_FIXTURE",
        limitations="Kết quả chỉ phản ánh bộ dữ liệu demo, không xác nhận đối tượng an toàn trong thực tế.",
    )


def _official_warning_evidence(compiled: dict[str, Any]) -> list[EvidenceItem]:
    items: list[EvidenceItem] = []
    if compiled["domain"] == "PUBLIC_AUTHORITY" and "TRANSFER_MONEY" in compiled["requested_actions"]:
        src1 = SOURCE_BY_ID["MPS-2026-09-08-25-SCENARIOS"]
        src2 = SOURCE_BY_ID["MPS-2026-04-01-CAOBANG"]
        items.extend([
            EvidenceItem(
                evidence_id="EV-OFFICIAL-WARNING-001",
                kind="OFFICIAL_WARNING",
                state="MATCH",
                label="Trùng kịch bản được cảnh báo chính thức",
                detail="Nguồn Bộ Công an mô tả thủ đoạn mạo danh cơ quan/tổ chức để yêu cầu chuyển tiền với lý do như 'xác minh thông tin'.",
                authority=src1["authority_class"],
                source_id=src1["source_id"],
                limitations=src1["limitations"],
            ),
            EvidenceItem(
                evidence_id="EV-PROCEDURE-COMPARE-001",
                kind="PROCEDURE_COMPARISON",
                state="DEVIATION",
                label="Có điểm không phù hợp với tuyến xác minh độc lập",
                detail="Yêu cầu chuyển tiền để 'xác minh' trùng với ca mạo danh Công an được cảnh báo; protective route là không giao dịch theo yêu cầu đó và xác minh qua kênh chính thức độc lập.",
                authority=src2["authority_class"],
                source_id=src2["source_id"],
                limitations=src2["limitations"],
            ),
        ])
    return items


def _education_procedure_evidence(
    compiled: dict[str, Any],
    account: str | None,
    *,
    procedure_state: str = "CURRENT",
    force_conflict: bool = False,
) -> list[EvidenceItem]:
    if compiled["domain"] != "EDUCATION" or "TRANSFER_TUITION" not in compiled["requested_actions"]:
        return []

    normalized = normalize_digits(account)
    if force_conflict:
        return [EvidenceItem(
            evidence_id="EV-PROCEDURE-CONFLICTED-001",
            kind="PROCEDURE_COMPARISON",
            state="CONFLICTED",
            label="Nguồn procedure đang mâu thuẫn",
            detail="Hai snapshot demo đưa ra recipient route khác nhau; hệ thống không được suy ra LOW từ trạng thái này.",
            authority="DEMO_AUTHORITY_FIXTURE",
            source_id="DEMO-SCHOOL-PROCEDURE-001",
            limitations="Conflict fixture phục vụ failure/degradation acceptance.",
        )]

    procedure = next(p for p in PROCEDURES if p["status"] == procedure_state)
    if procedure_state == "STALE":
        return [EvidenceItem(
            evidence_id="EV-PROCEDURE-STALE-001",
            kind="PROCEDURE_COMPARISON",
            state="STALE",
            label="Procedure snapshot đã hết hiệu lực",
            detail="Có procedure lịch sử nhưng snapshot đã hết thời hạn hiệu lực; không dùng để xác nhận route hiện tại.",
            authority=procedure["authority_class"],
            source_id=procedure["source_id"],
            limitations=procedure["notes"],
        )]

    if normalized in procedure["approved_recipient_accounts"]:
        return [EvidenceItem(
            evidence_id="EV-PROCEDURE-MATCH-001",
            kind="PROCEDURE_COMPARISON",
            state="MATCH",
            label="Khớp procedure fixture hiện hành",
            detail="Mục đích thanh toán và recipient account khớp snapshot procedure demo hiện hành.",
            authority=procedure["authority_class"],
            source_id=procedure["source_id"],
            limitations=procedure["notes"],
            metadata={"procedure_id": procedure["procedure_id"], "status": procedure["status"]},
        )]

    return [EvidenceItem(
        evidence_id="EV-PROCEDURE-DEVIATION-EDU-001",
        kind="PROCEDURE_COMPARISON",
        state="DEVIATION",
        label="Recipient route không khớp procedure fixture",
        detail="Tài khoản nhận không trùng danh sách recipient account trong snapshot procedure demo hiện hành.",
        authority=procedure["authority_class"],
        source_id=procedure["source_id"],
        limitations=procedure["notes"],
        metadata={"procedure_id": procedure["procedure_id"], "status": procedure["status"]},
    )]


def _reviewed_memory_evidence(
    compiled: dict[str, Any],
    *,
    memory_available: bool = True,
    memory_enabled: bool = True,
) -> list[EvidenceItem]:
    if compiled["domain"] != "ECOMMERCE":
        return []
    if not memory_available:
        return [EvidenceItem(
            evidence_id="EV-MEMORY-UNAVAILABLE-001",
            kind="REVIEWED_PATTERN",
            state="UNAVAILABLE",
            label="Reviewed memory hiện không khả dụng",
            detail="Không thể thực hiện pattern retrieval trong lần kiểm tra này.",
            authority="DEMO_FIXTURE",
            limitations="UNAVAILABLE không được diễn giải thành NO_MATCH.",
        )]
    if not memory_enabled:
        return [EvidenceItem(
            evidence_id="EV-MEMORY-DISABLED-001",
            kind="REVIEWED_PATTERN",
            state="NOT_APPLICABLE",
            label="Reviewed memory bị tắt cho baseline",
            detail="Baseline acceptance chạy cùng tình huống nhưng không sử dụng reviewed memory.",
            authority="DEMO_FIXTURE",
            limitations="Dùng để đo contribution của Hero 3.",
        )]

    pattern = PATTERNS[0]
    observed = set(compiled["context_signals"])
    expected = set(pattern["signals"])
    overlap = len(observed & expected) / len(expected) if expected else 0.0
    if overlap >= 0.75:
        return [EvidenceItem(
            evidence_id="EV-MEMORY-SIMILAR-001",
            kind="REVIEWED_PATTERN",
            state="SIMILAR_REVIEWED",
            label="Tương tự reviewed pattern trong bộ nhớ demo",
            detail="Các tín hiệu tình huống có overlap cao với pattern đã qua review: rời nền tảng + chuyển tiền + urgency + người bán mới.",
            authority=pattern["authority_class"],
            source_id="DEMO-REVIEWED-MEMORY-001",
            limitations=pattern["limitations"],
            metadata={"pattern_id": pattern["pattern_id"], "signal_overlap": round(overlap, 3), "status": pattern["status"]},
        )]

    return [EvidenceItem(
        evidence_id="EV-MEMORY-NO-MATCH-001",
        kind="REVIEWED_PATTERN",
        state="NO_MATCH",
        label="Không có reviewed pattern đủ tương tự trong demo",
        detail="Pattern retrieval đã chạy nhưng không đạt threshold demo.",
        authority=pattern["authority_class"],
        source_id="DEMO-REVIEWED-MEMORY-001",
        limitations="NO_MATCH không phải bằng chứng tình huống an toàn.",
        metadata={"pattern_id": pattern["pattern_id"], "signal_overlap": round(overlap, 3), "status": pattern["status"]},
    )]


def _decision_hash(payload: dict[str, Any]) -> str:
    canonical = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def decide(
    situation: str,
    phone: str | None = None,
    account: str | None = None,
    action_state: str | None = None,
    *,
    identifier_source_available: bool = True,
    procedure_state: str = "CURRENT",
    force_procedure_conflict: bool = False,
    reviewed_memory_available: bool = True,
    reviewed_memory_enabled: bool = True,
    attachments: list[dict[str, Any]] | None = None,
) -> DecisionResult:
    total_start = time.perf_counter()
    stage_ms: dict[str, float] = {}

    s = time.perf_counter()
    redaction = redact_secrets(situation)
    compiled = _compile_case(redaction.text, action_state)
    stage_ms["intake_compile"] = _ms(s)

    # Fast safety path stops at a bounded action class; it does not assert fraud truth.
    s = time.perf_counter()
    if compiled["action_state"] == "ALREADY_TRANSFERRED":
        fast_action = "RECOVER"
    elif compiled["domain"] == "PUBLIC_AUTHORITY" and "TRANSFER_MONEY" in compiled["requested_actions"]:
        fast_action = "PAUSE_VERIFY"
    elif compiled["high_consequence"]:
        fast_action = "PAUSE"
    else:
        fast_action = "CONTINUE_CAUTION"
    stage_ms["fast_policy"] = _ms(s)
    ttfp_ms = round(sum(stage_ms.values()), 3)

    s = time.perf_counter()
    evidence: list[EvidenceItem] = [
        _lookup_identifier("PHONE", phone, available=identifier_source_available),
        _lookup_identifier("ACCOUNT", account, available=identifier_source_available),
    ]
    stage_ms["identifier_lookup"] = _ms(s)

    s = time.perf_counter()
    evidence.extend(_official_warning_evidence(compiled))
    evidence.extend(_education_procedure_evidence(
        compiled,
        account,
        procedure_state=procedure_state,
        force_conflict=force_procedure_conflict,
    ))
    stage_ms["procedure_context"] = _ms(s)

    s = time.perf_counter()
    evidence.extend(_reviewed_memory_evidence(
        compiled,
        memory_available=reviewed_memory_available,
        memory_enabled=reviewed_memory_enabled,
    ))
    stage_ms["reviewed_memory"] = _ms(s)

    s = time.perf_counter()
    attachment_items = attachments or []
    for idx, item in enumerate(attachment_items[:3], start=1):
        state = item.get("state", "ACCEPTED_METADATA_ONLY")
        if state == "QR_DECODED":
            detail = f"QR payload đã được decode cục bộ ({item.get('qr_payload_type','UNKNOWN')}); đây là observation, không phải verdict."
            label = "Đã đọc QR từ ảnh"
            kind = "QR_OBSERVATION"
        else:
            detail = "Ảnh được ghi nhận bằng fingerprint/metadata; P3 không OCR ảnh chung."
            label = "Ảnh đã được tiếp nhận"
            kind = "IMAGE_OBSERVATION"
        evidence.append(EvidenceItem(
            evidence_id=f"EV-ATTACHMENT-{idx:02d}",
            kind=kind,
            state=state,
            label=label,
            detail=detail,
            authority="USER_SUPPLIED_EVIDENCE",
            limitations=item.get("limitations"),
            metadata={
                "sha256": item.get("sha256"),
                "width": item.get("width"),
                "height": item.get("height"),
                "content_type": item.get("content_type"),
                "qr_payload_type": item.get("qr_payload_type"),
                "qr_payload": item.get("qr_payload"),
                "raw_file_persisted": False,
            },
        ))
    stage_ms["attachment_observation"] = _ms(s)

    s = time.perf_counter()
    high_consequence = compiled["high_consequence"]
    state = compiled["action_state"]
    adverse = any(e.kind == "OFFICIAL_WARNING" and e.state == "MATCH" for e in evidence)
    procedure_deviation = any(e.kind == "PROCEDURE_COMPARISON" and e.state == "DEVIATION" for e in evidence)
    procedure_match = any(e.kind == "PROCEDURE_COMPARISON" and e.state == "MATCH" for e in evidence)
    procedure_unreliable = any(e.kind == "PROCEDURE_COMPARISON" and e.state in {"STALE", "CONFLICTED", "UNAVAILABLE"} for e in evidence)
    reviewed_similar = any(e.kind == "REVIEWED_PATTERN" and e.state == "SIMILAR_REVIEWED" for e in evidence)
    verified_recipient = any(e.kind == "ACCOUNT" and e.state == "VERIFIED_REFERENCE" for e in evidence)

    if state == "ALREADY_TRANSFERRED":
        concern_level = "URGENT_RECOVER"
        concern_label = "KHẨN CẤP — KHÔI PHỤC"
        headline = "Ưu tiên ngắt liên hệ và bắt đầu khôi phục ngay."
        action_class = "RECOVER"
        actions = [
            "Kết thúc kênh liên hệ hiện tại với bên đang gây áp lực.",
            "Liên hệ ngân hàng qua kênh chính thức để báo giao dịch và làm theo hướng dẫn khẩn cấp.",
            "Giữ lại tin nhắn, số điện thoại, biên lai và bằng chứng liên quan.",
        ]
    elif high_consequence and (adverse or procedure_deviation):
        concern_level = "HIGH_NOT_DONE"
        concern_label = "CAO — CHƯA THỰC HIỆN"
        headline = "Chưa thực hiện bước tài chính tiếp theo. Xác minh độc lập trước khi làm tiếp."
        action_class = "PREVENT_VERIFY"
        actions = [
            "Chưa chuyển tiền hoặc thực hiện bước tài chính tiếp theo.",
            "Kết thúc cuộc gọi/phiên liên hệ hiện tại nếu đang bị hướng dẫn liên tục.",
            "Tự tìm kênh chính thức của cơ quan/tổ chức để xác minh độc lập.",
        ]
    elif high_consequence and reviewed_similar:
        concern_level = "HIGH_NOT_DONE"
        concern_label = "CAO — CẦN DỪNG VÀ XÁC MINH"
        headline = "Tình huống tương tự reviewed pattern; chưa đặt cọc/chuyển tiền ngoài nền tảng."
        action_class = "PREVENT_VERIFY"
        actions = [
            "Không chuyển tiền/đặt cọc ngoài nền tảng trong phiên hiện tại.",
            "Quay lại kênh chính thức của nền tảng để kiểm tra người bán và điều kiện giao dịch.",
            "Chỉ tiếp tục khi recipient route và giao dịch được xác minh độc lập.",
        ]
    elif procedure_match and verified_recipient and not adverse and not procedure_unreliable:
        concern_level = "LOW_BOUNDED"
        concern_label = "THẤP TRONG PHẠM VI ĐÃ KIỂM TRA"
        headline = "Yêu cầu phù hợp procedure fixture hiện hành; không có hard-stop trong phạm vi demo."
        action_class = "VERIFY_LIGHT"
        actions = [
            "Đối chiếu lần cuối tên/mục đích thanh toán trên kênh chính thức trước khi xác nhận.",
            "Nếu có bất kỳ thay đổi recipient, kênh hoặc yêu cầu mới, dừng và kiểm tra lại.",
        ]
    elif high_consequence and procedure_unreliable:
        concern_level = "VERIFY"
        concern_label = "CẦN KIỂM TRA — NGUỒN CHƯA ĐỦ TIN CẬY"
        headline = "Có hành động hậu quả cao nhưng procedure hiện stale/conflicted; chưa đủ cơ sở để hạ mức cảnh báo."
        action_class = "PAUSE_VERIFY"
        actions = ["Tạm dừng bước khó đảo ngược và xác minh bằng procedure/kênh chính thức hiện hành."]
    elif high_consequence:
        concern_level = "VERIFY"
        concern_label = "CẦN KIỂM TRA"
        headline = "Có hành động hậu quả cao nhưng bằng chứng hiện chưa đủ để xác nhận route phù hợp."
        action_class = "PAUSE_VERIFY"
        actions = ["Tạm dừng bước khó đảo ngược và xác minh qua kênh chính thức độc lập."]
    else:
        concern_level = "LOW_BOUNDED"
        concern_label = "THẤP TRONG PHẠM VI DỮ LIỆU HIỆN CÓ"
        headline = "Chưa phát hiện dấu hiệu bất lợi đáng kể trong phạm vi kiểm tra hiện tại."
        action_class = "CONTINUE_CAUTION"
        actions = ["Tiếp tục thận trọng và kiểm tra lại nếu xuất hiện yêu cầu bất thường mới."]
    stage_ms["deterministic_policy"] = _ms(s)

    reasons: list[str] = []
    if adverse:
        reasons.append("Yêu cầu hiện tại trùng một kịch bản mạo danh/chuyển tiền đã được Bộ Công an cảnh báo công khai.")
    if procedure_deviation:
        reasons.append("Recipient/action route lệch khỏi procedure reference đang được dùng cho quyết định bảo vệ.")
    if procedure_match:
        reasons.append("Mục đích và recipient route khớp procedure fixture hiện hành của Hero 2.")
    if reviewed_similar:
        reasons.append("Reviewed memory đóng góp một pattern similarity có provenance; đây là protective signal, không phải fraud verdict.")
    if any(e.state == "NO_MATCH" for e in evidence if e.kind in {"PHONE", "ACCOUNT"}):
        reasons.append("Một hoặc nhiều identifier chưa có adverse match trong dữ liệu demo; điều này không phải bằng chứng an toàn.")
    if procedure_unreliable:
        reasons.append("Procedure evidence đang stale/conflicted nên hệ thống không được hạ mức concern dựa trên nguồn đó.")
    if compiled["high_consequence"]:
        reasons.append("Hành động được yêu cầu có hậu quả tài chính hoặc quyền kiểm soát khó đảo ngược.")

    unknowns: list[str] = []
    if compiled["claimed_identity"]:
        unknowns.append("Danh tính thực của chủ thể liên hệ chưa được xác minh độc lập.")
    if account and not verified_recipient:
        unknowns.append("Chủ tài khoản nhận tiền chưa được xác minh bằng nguồn có thẩm quyền trong demo.")
    if phone:
        unknowns.append("Quan hệ giữa số điện thoại và tổ chức được mô tả/tự xưng chưa được xác minh.")
    if not unknowns:
        unknowns.append("Không có unknown bắt buộc nào khác trong phạm vi fixture đang dùng; điều này không phải bảo đảm an toàn tuyệt đối.")

    verification_steps = [
        "Không dùng riêng số điện thoại/link do bên đang liên hệ cung cấp làm căn cứ tự xác minh.",
        "Tự mở website/app/kênh chính thức đã biết trước của cơ quan, trường, ngân hàng hoặc nền tảng liên quan.",
        "Nếu đã chuyển tiền hoặc lộ credential, ưu tiên liên hệ ngân hàng/tổ chức qua thiết bị/kênh đáng tin cậy.",
    ]

    evidence_dicts = [asdict(item) for item in evidence]
    decision_payload = {
        "release": RELEASE_VERSION,
        "concern_level": concern_level,
        "action_class": action_class,
        "actions": actions,
        "reasons": reasons,
        "evidence": evidence_dicts,
        "understood": compiled,
        "policy_version": POLICY_VERSION,
        "resolver_version": RESOLVER_VERSION,
        "data_version": DATA_VERSION,
        "procedure_version": PROCEDURE_VERSION,
        "memory_version": MEMORY_VERSION,
        "attachment_fingerprints": [item.get("sha256") for item in (attachments or [])[:3]],
    }
    decision_hash = _decision_hash(decision_payload)
    total_ms = _ms(total_start)

    capability = {
        "identifier_lookup": "AVAILABLE" if identifier_source_available else "UNAVAILABLE",
        "official_warning": "AVAILABLE",
        "procedure_intelligence": procedure_state if not force_procedure_conflict else "CONFLICTED",
        "reviewed_memory": "AVAILABLE" if reviewed_memory_available else "UNAVAILABLE",
        "image_qr_acquisition": "AVAILABLE_LOCAL_ONLY",
        "generic_image_ocr": "NOT_ENABLED",
        "enforcement_authority": "NOT_GRANTED",
    }
    trace = {
        "release": RELEASE_VERSION,
        "policy_version": POLICY_VERSION,
        "resolver_version": RESOLVER_VERSION,
        "data_version": DATA_VERSION,
        "procedure_version": PROCEDURE_VERSION,
        "memory_version": MEMORY_VERSION,
        "decision_hash": decision_hash,
        "attachment_count": str(len((attachments or [])[:3])),
    }
    performance = {
        "ttfp_ms": ttfp_ms,
        "total_ms": total_ms,
        "stage_ms": stage_ms,
        "fast_action_class": fast_action,
        "timing_scope": "LOCAL_PROCESS_ONLY",
    }

    return DecisionResult(
        case_id=f"PAR-{uuid.uuid4().hex[:10].upper()}",
        release=RELEASE_VERSION,
        concern_level=concern_level,
        concern_label=concern_label,
        headline=headline,
        action_class=action_class,
        actions=actions,
        reasons=reasons,
        unknowns=unknowns,
        verification_steps=verification_steps,
        evidence=evidence_dicts,
        understood=compiled,
        capability=capability,
        trace=trace,
        performance=performance,
        redaction={"redacted": bool(redaction.redacted_types), "types": list(redaction.redacted_types)},
        disclaimer=(
            "PAR đưa ra hành động bảo vệ trong phạm vi evidence hiện có; không kết luận một cá nhân/tài khoản là gian lận, "
            "không thay thế cơ quan có thẩm quyền và không tự động thực thi giao dịch."
        ),
    )
