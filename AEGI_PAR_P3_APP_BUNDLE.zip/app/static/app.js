const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];
let lastResult = null;
let profiles = [];
let attachmentTokens = [];
let lastAttachment = null;
const LAST_CASE_KEY = 'aegi_par_p3_last_case';

function show(id){ $$('.view').forEach(v=>v.classList.remove('active')); $(id).classList.add('active'); window.scrollTo({top:0,behavior:'smooth'}); }
function toast(msg){ const t=$('#toast'); t.textContent=msg; t.classList.add('show'); setTimeout(()=>t.classList.remove('show'),2600); }
function escapeHtml(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function li(items){return (items||[]).map(x=>`<li>${escapeHtml(x)}</li>`).join('');}
function concernClass(level){return level?.startsWith('HIGH')||level?.startsWith('URGENT')?'high':level==='VERIFY'?'verify':'low';}
function stateClass(state){
  if(['MATCH','VERIFIED_REFERENCE'].includes(state)) return 'state-good';
  if(['DEVIATION','SIMILAR_REVIEWED'].includes(state)) return 'state-warn';
  if(['UNAVAILABLE','STALE','CONFLICTED'].includes(state)) return 'state-neutral';
  return 'state-neutral';
}

async function loadProfiles(){
  const res = await fetch('/api/v1/demo/profiles');
  const data = await res.json(); profiles = data.profiles || [];
  const labels=['01','02','03'];
  $('#proofGrid').innerHTML = profiles.map((p,i)=>`<article class="proof-card">
    <div class="proof-number">${labels[i]||String(i+1).padStart(2,'0')}</div>
    <div><span class="tag">${escapeHtml(p.label.split(' · ')[0])}</span><h3>${escapeHtml(p.label.split(' · ')[1]||p.label)}</h3><p>${escapeHtml(p.thesis)}</p></div>
    <button class="text-button load-profile" data-profile="${escapeHtml(p.id)}">Nạp case →</button>
  </article>`).join('');
  $$('.load-profile').forEach(b=>b.addEventListener('click',()=>loadProfile(b.dataset.profile)));
}

function clearAttachment(){
  attachmentTokens=[]; lastAttachment=null; $('#evidenceFile').value='';
  $('#uploadStatus').hidden=true; $('#uploadStatus').textContent='';
  updateTray();
}
function loadProfile(id){
  const p=profiles.find(x=>x.id===id); if(!p) return;
  clearAttachment(); show('#intake');
  $('#situation').value=p.situation; $('#phone').value=p.phone||''; $('#account').value=p.account||''; $('#actionState').value=p.action_state||'UNKNOWN';
  updateTray(); updateCount(); toast(`Đã nạp ${p.label}`);
}

$$('[data-entry]').forEach(btn=>btn.addEventListener('click',()=>{
  const mode=btn.dataset.entry; clearAttachment(); show('#intake');
  if(mode==='quick') $('#situation').placeholder='Ví dụ: Số này gọi tự xưng ngân hàng và yêu cầu tôi chuyển tiền để xác minh...';
  if(mode==='recovery') $('#actionState').value='ALREADY_TRANSFERRED';
}));
$$('[data-back]').forEach(btn=>btn.addEventListener('click',()=>show('#home')));

function updateTray(){
  $('#trayPhone').classList.toggle('active',!!$('#phone').value.trim());
  $('#trayAccount').classList.toggle('active',!!$('#account').value.trim());
  $('#trayQr').classList.toggle('active',lastAttachment?.kind==='QR_IMAGE');
  $('#trayImage').classList.toggle('active',!!lastAttachment);
}
function updateCount(){ $('#charCount').textContent=$('#situation').value.length; }
['phone','account'].forEach(id=>$('#'+id).addEventListener('input',updateTray));
$('#situation').addEventListener('input',updateCount);

$('#evidenceFile').addEventListener('change', async()=>{
  const file=$('#evidenceFile').files?.[0]; if(!file){clearAttachment(); return;}
  const status=$('#uploadStatus'); status.hidden=false; status.className='upload-status'; status.textContent='Đang kiểm tra ảnh cục bộ…';
  const fd=new FormData(); fd.append('file',file);
  try{
    const res=await fetch('/api/v1/uploads/image',{method:'POST',body:fd});
    const data=await res.json().catch(()=>({}));
    if(!res.ok) throw new Error(data.detail||'Không thể tiếp nhận ảnh');
    lastAttachment=data.attachment; attachmentTokens=[data.attachment.attachment_token];
    status.classList.add(lastAttachment.state==='QR_DECODED'?'good':'warn');
    status.innerHTML=lastAttachment.state==='QR_DECODED'
      ? `<strong>QR đã decode.</strong> Loại payload: ${escapeHtml(lastAttachment.qr_payload_type||'UNKNOWN')}. Raw ảnh không được lưu.`
      : `<strong>Ảnh đã tiếp nhận.</strong> ${escapeHtml(lastAttachment.width)}×${escapeHtml(lastAttachment.height)} · fingerprint ${escapeHtml(lastAttachment.sha256.slice(0,12))}… · không OCR · raw ảnh không được lưu.`;
    updateTray();
  }catch(err){ attachmentTokens=[]; lastAttachment=null; status.classList.add('bad'); status.textContent=err.message||'Không thể tiếp nhận ảnh'; updateTray(); }
});

$('#checkForm').addEventListener('submit',async(e)=>{
  e.preventDefault();
  const button=e.submitter; button.disabled=true; button.textContent='Đang đối chiếu…';
  try{
    const res=await fetch('/api/v1/check',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({
      situation:$('#situation').value,
      phone:$('#phone').value||null,
      account:$('#account').value||null,
      action_state:$('#actionState').value,
      attachment_tokens:attachmentTokens
    })});
    const data=await res.json().catch(()=>({}));
    if(!res.ok) throw new Error(data.detail||'Không thể xử lý yêu cầu');
    lastResult=data; localStorage.setItem(LAST_CASE_KEY,lastResult.case_id); renderResult(lastResult); show('#result'); updateResumeCard();
  }catch(err){ toast(err.message||'Có lỗi xảy ra'); }
  finally{button.disabled=false; button.textContent='Kiểm tra tình huống';}
});

function renderResult(r){
  const understood=[];
  if(r.understood?.domain) understood.push(r.understood.domain);
  if(r.understood?.claimed_identity) understood.push(r.understood.claimed_identity);
  (r.understood?.requested_actions||[]).forEach(a=>understood.push(a.replaceAll('_',' ')));
  if(r.understood?.action_state) understood.push(r.understood.action_state.replaceAll('_',' '));
  const perf=r.performance||{}; const pers=r.persistence||{};
  const degraded=Object.entries(r.capability||{}).filter(([_,v])=>['UNAVAILABLE','STALE','CONFLICTED'].includes(v));
  $('#resultMount').innerHTML=`
    <div class="result-hero">
      <div class="result-title-row"><span class="concern ${concernClass(r.concern_level)}">${escapeHtml(r.concern_label)}</span><span class="action-class">${escapeHtml(r.action_class)}</span></div>
      <h2>${escapeHtml(r.headline)}</h2>
      <div class="caseid">Case ${escapeHtml(r.case_id)} · ${escapeHtml(r.release)} · Policy ${escapeHtml(r.trace?.policy_version)}</div>
      <div class="understood"><strong>PAR hiểu gì từ tình huống?</strong><div class="chips">${understood.map(x=>`<span class="chip">${escapeHtml(x)}</span>`).join('')}</div></div>
      ${r.redaction?.redacted?`<div class="redaction">PAR đã ẩn bí mật phát hiện trong mô tả: ${escapeHtml(r.redaction.types.join(', '))}.</div>`:''}
      ${degraded.length?`<div class="redaction">Một số nguồn đang degraded: ${degraded.map(([k,v])=>`${escapeHtml(k)}=${escapeHtml(v)}`).join(' · ')}. Hệ thống không suy ra SAFE từ trạng thái này.</div>`:''}
      <div class="perf-strip"><span><b>${escapeHtml(perf.ttfp_ms??'—')} ms</b><small>time to first protection*</small></span><span><b>${escapeHtml(perf.total_ms??'—')} ms</b><small>local decision path*</small></span><span><b>${escapeHtml(perf.fast_action_class??'—')}</b><small>fast-path class</small></span></div>
      <div class="persistence-strip"><span>TTL ${escapeHtml(pers.ttl_hours??'24')}h</span><span>raw input persisted: NO</span><span>raw image persisted: NO</span></div>
    </div>
    <div class="result-grid">
      <div class="result-block"><h3>Làm gì ngay</h3><ul>${li(r.actions)}</ul></div>
      <div class="result-block"><h3>Vì sao</h3><ul>${li(r.reasons)}</ul></div>
      <div class="result-block"><h3>Chưa xác minh</h3><ul>${li(r.unknowns)}</ul></div>
      <div class="result-block"><h3>Xác minh thế nào</h3><ul>${li(r.verification_steps)}</ul></div>
    </div>
    <div class="result-actions"><button class="secondary" id="showEvidence">Xem bằng chứng, nguồn & trace</button><button class="secondary" id="newCheck">Kiểm tra mới</button><button class="secondary danger" id="deleteCase">Xóa ca này</button></div>
    <p class="disclaimer">${escapeHtml(r.disclaimer)} *Latency chỉ đo local process P3, không đại diện latency tích hợp nguồn thật.</p>`;
  $('#showEvidence').addEventListener('click',openEvidence);
  $('#newCheck').addEventListener('click',newCheck);
  $('#deleteCase').addEventListener('click',deleteCurrentCase);
}

async function openEvidence(){
  if(!lastResult)return;
  const res=await fetch(`/api/v1/cases/${encodeURIComponent(lastResult.case_id)}/evidence`); const data=await res.json();
  if(!res.ok){toast(data.detail||'Evidence không còn khả dụng'); return;}
  const sourceMap=Object.fromEntries((data.sources||[]).map(s=>[s.source_id,s]));
  $('#evidenceMount').innerHTML=`<div class="evidence-body">
    <div class="capability-grid">${Object.entries(data.capability||{}).map(([k,v])=>`<div><small>${escapeHtml(k)}</small><strong>${escapeHtml(v)}</strong></div>`).join('')}</div>
    ${data.evidence.map(e=>`<div class="evidence-item"><div class="evidence-top"><strong>${escapeHtml(e.kind)}</strong><span class="state ${stateClass(e.state)}">${escapeHtml(e.state)}</span></div><p><b>${escapeHtml(e.label)}</b><br>${escapeHtml(e.detail)}</p>${e.metadata?`<pre class="metadata">${escapeHtml(JSON.stringify(e.metadata,null,2))}</pre>`:''}${e.limitations?`<p><small>Giới hạn: ${escapeHtml(e.limitations)}</small></p>`:''}${e.source_id&&sourceMap[e.source_id]?`<div class="source-card"><small>${escapeHtml(sourceMap[e.source_id].authority_class)} · ${escapeHtml(sourceMap[e.source_id].published_at)}</small><br>${sourceMap[e.source_id].canonical_url?`<a href="${escapeHtml(sourceMap[e.source_id].canonical_url)}" target="_blank" rel="noopener">${escapeHtml(sourceMap[e.source_id].title)} ↗</a>`:`<strong>${escapeHtml(sourceMap[e.source_id].title)}</strong>`}<p>${escapeHtml(sourceMap[e.source_id].limitations||'')}</p></div>`:''}</div>`).join('')}
    <div class="trace"><b>TRACE</b><br>${Object.entries(data.trace||{}).map(([k,v])=>`${escapeHtml(k)}=${escapeHtml(v)}`).join('<br>')}<br><br><b>PERFORMANCE</b><br>${escapeHtml(JSON.stringify(data.performance||{},null,2))}<br><br><b>PERSISTENCE</b><br>${escapeHtml(JSON.stringify(data.persistence||{},null,2))}</div>
  </div>`;
  $('#evidenceDialog').showModal();
}
$('#closeEvidence').addEventListener('click',()=>$('#evidenceDialog').close());

function newCheck(){ $('#checkForm').reset(); clearAttachment(); updateTray(); updateCount(); lastResult=null; show('#home'); }
async function deleteCurrentCase(){
  if(!lastResult) return;
  await fetch(`/api/v1/cases/${encodeURIComponent(lastResult.case_id)}`,{method:'DELETE'});
  localStorage.removeItem(LAST_CASE_KEY); lastResult=null; updateResumeCard(); newCheck(); toast('Ca đã được xóa khỏi persistence demo');
}

async function updateResumeCard(){
  const id=localStorage.getItem(LAST_CASE_KEY); const card=$('#resumeCard');
  if(!id){card.hidden=true;return;}
  try{ const res=await fetch(`/api/v1/cases/${encodeURIComponent(id)}`); if(!res.ok) throw new Error(); lastResult=await res.json(); card.hidden=false; }
  catch(_){localStorage.removeItem(LAST_CASE_KEY); card.hidden=true;}
}
$('#resumeCase').addEventListener('click',()=>{if(lastResult){renderResult(lastResult);show('#result');}});

Promise.all([loadProfiles(),updateResumeCard()]).catch(()=>toast('Không tải được một phần dữ liệu demo'));
