from __future__ import annotations

import re
from dataclasses import dataclass


@dataclass(frozen=True)
class RedactionResult:
    text: str
    redacted_types: tuple[str, ...]


_SECRET_PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    ("OTP", re.compile(r"(?i)\b(otp|mã\s*(?:otp|xác\s*thực|xac\s*thuc))\s*[:=-]?\s*(\d{4,8})\b")),
    ("PIN", re.compile(r"(?i)\b(pin)\s*[:=-]?\s*(\d{4,8})\b")),
    ("CVV", re.compile(r"(?i)\b(cvv|cvc)\s*[:=-]?\s*(\d{3,4})\b")),
    # Require either an explicit delimiter or a secret-like token that is not a common connector word.
    # This avoids treating Vietnamese phrases such as "mật khẩu cho người gọi" as if "cho" were the secret value.
    ("PASSWORD", re.compile(r"(?i)\b(mật\s*khẩu|mat\s*khau|password|pass)\s*(?:(?:[:=-]\s*)([^\s,;]+)|\s+((?!(?:cho|cua|của|voi|với|la|là|da|đã|chua|chưa|khong|không|bi|bị|duoc|được)\b)(?=[^\s,;]*[0-9!@#$%^&*_.-])[^\s,;]+))")),
]


def redact_secrets(text: str) -> RedactionResult:
    """Redact high-risk secrets before downstream processing.

    Phone/account fields are handled separately and are intentionally not redacted here.
    """
    redacted_types: list[str] = []
    cleaned = text or ""
    for kind, pattern in _SECRET_PATTERNS:
        if pattern.search(cleaned):
            redacted_types.append(kind)
            cleaned = pattern.sub(lambda m: f"{m.group(1)}: [ĐÃ ẨN]", cleaned)
    return RedactionResult(cleaned, tuple(dict.fromkeys(redacted_types)))


def normalize_digits(value: str | None) -> str | None:
    if value is None:
        return None
    digits = re.sub(r"\D", "", value)
    return digits or None
