"""Versioned internal action templates. No external authority or NLU claim."""
import copy
import hashlib
import json

VERSION = 'PAR-ACTION-TEMPLATES-v0.2'
VERIFY = ['Tự mở kênh chính thức đã biết trước hoặc tự tìm số liên hệ độc lập; không dùng riêng số/link do bên liên hệ cung cấp.']

def entry(action, concern, label, headline, actions, intents):
    return dict(action_class=action, concern_level=concern, concern_label=label, headline=headline,
                actions=actions, verification_steps=VERIFY, action_intents=intents)

TEMPLATES = {
 'PREVENT':entry('PREVENT_VERIFY','HIGH_NOT_DONE','CAO — CẦN DỪNG VÀ XÁC MINH',
   'Tạm dừng yêu cầu đang có dấu hiệu đáng lo và xác minh độc lập.',
   ['Chưa chuyển tiền theo yêu cầu đang được kiểm tra.', 'Không cung cấp OTP/mật khẩu cho người liên hệ, không cho họ điều khiển thiết bị hoặc chia sẻ màn hình.', 'Tự liên hệ tổ chức qua kênh độc lập trước khi quyết định bước tiếp theo.'],
   ['PAUSE_PAYMENT','DO_NOT_DISCLOSE','DO_NOT_GRANT_CONTROL','VERIFY_INDEPENDENTLY']),
 'PAUSE':entry('PAUSE_VERIFY','VERIFY','CẦN KIỂM TRA',
   'Thông tin hoặc phạm vi xác minh chưa đủ; cần làm rõ trước bước khó đảo ngược.',
   ['Tạm dừng bước thanh toán hoặc cấp quyền đang được cân nhắc.', 'Làm rõ người yêu cầu, cách dùng OTP/thiết bị và phạm vi khoản thu qua kênh chính thức độc lập.'],
   ['PAUSE_PAYMENT','CLARIFY','VERIFY_INDEPENDENTLY']),
 'LIGHT':entry('VERIFY_LIGHT','LOW_BOUNDED','THẤP TRONG PHẠM VI ĐÃ KIỂM TRA',
   'Các thông tin được mô tả phù hợp phạm vi fixture; đối chiếu lần cuối trên kênh độc lập.',
   ['Tự mở cổng chính thức để đối chiếu tổ chức, mục đích, số tiền và tài khoản trước khi xác nhận.', 'Không chia sẻ OTP hoặc cấp quyền điều khiển cho người liên hệ; dừng nếu xuất hiện yêu cầu mới.'],
   ['LIGHT_CHECK','DO_NOT_DISCLOSE','DO_NOT_GRANT_CONTROL']),
 'RECOVER':entry('RECOVER','URGENT_RECOVER','KHẨN CẤP — KHÔI PHỤC',
   'Có hành động đã thực hiện cùng dấu hiệu đáng lo; ưu tiên hạn chế thiệt hại.',
   ['Ngắt phiên liên hệ hoặc điều khiển đáng ngờ nếu đang diễn ra.', 'Dùng thiết bị/kênh đáng tin cậy để liên hệ ngân hàng hoặc đơn vị quản lý tài khoản, báo giao dịch/lộ thông tin và yêu cầu hướng dẫn bảo vệ tài khoản.', 'Giữ biên lai và bằng chứng; khả năng thu hồi cần được đơn vị có thẩm quyền xác nhận, không được bảo đảm.'],
   ['END_SUSPICIOUS_SESSION','CONTACT_INSTITUTION','SECURE_ACCOUNT','PRESERVE_EVIDENCE']),
 'COMPLETED_CHECK':entry('PAUSE_VERIFY','VERIFY','CẦN LÀM RÕ',
   'Giao dịch đã hoàn tất nhưng chưa đủ thông tin để xác định cần khôi phục hay không.',
   ['Đối chiếu biên lai, khoản thu và tài khoản nhận qua kênh chính thức độc lập.', 'Chưa thực hiện yêu cầu bổ sung khó đảo ngược; nếu phát hiện chuyển nhầm hoặc lộ thông tin, liên hệ đơn vị quản lý tài khoản.'],
   ['CLARIFY_COMPLETED','VERIFY_INDEPENDENTLY']),
 'COMPLETED_RECORD':entry('CONTINUE_CAUTION','LOW_BOUNDED','ĐỐI CHIẾU SAU GIAO DỊCH',
   'Trong phạm vi thông tin này chưa có căn cứ yêu cầu khôi phục khẩn cấp.',
   ['Lưu biên lai và kiểm tra ghi nhận khoản thu trên kênh chính thức.', 'Nếu phát sinh dấu hiệu bất thường hoặc yêu cầu mới, kiểm tra lại trước khi hành động.'],
   ['KEEP_RECEIPT','CHECK_POSTED_PAYMENT']),
 'GENERAL':entry('CONTINUE_CAUTION','VERIFY','CẦN THÊM THÔNG TIN',
   'Chưa xác định được một yêu cầu giao dịch cụ thể từ mô tả.',
   ['Bổ sung người yêu cầu, hành động cần thực hiện và thời điểm; không cung cấp OTP hoặc mật khẩu.'],
   ['CLARIFY','DO_NOT_DISCLOSE']),
}

def content_hash(data):
    return hashlib.sha256(json.dumps(data,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def render(key):
    out=copy.deepcopy(TEMPLATES[key])
    intents=out.pop('action_intents')
    out['action_contract']={'version':VERSION,'template_id':key,'intent_codes':intents,
                            'verification_route':'INDEPENDENT_REQUIRED','assertion_codes':[],
                            'presentation_sha256':content_hash(out),
                            'review_authority':'INTERNAL_TEMPLATE_REVIEW_NOT_INDEPENDENT'}
    return out
