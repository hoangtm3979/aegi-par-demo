from __future__ import annotations

import hashlib
import io
import uuid
from typing import Any

import cv2
import numpy as np
from fastapi import UploadFile
from PIL import Image, UnidentifiedImageError

from .security import redact_secrets

MAX_UPLOAD_BYTES = 5 * 1024 * 1024
MAX_PIXELS = 16_000_000
ALLOWED_TYPES = {"image/png", "image/jpeg", "image/webp"}


class AcquisitionError(ValueError):
    pass


def _classify_qr(value: str) -> str:
    lower = value.strip().casefold()
    if lower.startswith(("https://", "http://")):
        return "URL"
    if lower.startswith(("000201", "napas", "vietqr")):
        return "PAYMENT_PAYLOAD"
    return "TEXT"


async def inspect_image(upload: UploadFile) -> tuple[str, dict[str, Any]]:
    content_type = (upload.content_type or "").lower()
    if content_type not in ALLOWED_TYPES:
        raise AcquisitionError("Chỉ chấp nhận PNG, JPEG hoặc WebP.")
    raw = await upload.read(MAX_UPLOAD_BYTES + 1)
    await upload.close()
    if not raw:
        raise AcquisitionError("Tệp ảnh rỗng.")
    if len(raw) > MAX_UPLOAD_BYTES:
        raise AcquisitionError("Ảnh vượt giới hạn 5 MB.")

    try:
        with Image.open(io.BytesIO(raw)) as img:
            width, height = img.size
            fmt = img.format
            if width <= 0 or height <= 0 or width * height > MAX_PIXELS:
                raise AcquisitionError("Kích thước ảnh vượt giới hạn an toàn của demo.")
            rgb = img.convert("RGB")
            arr = np.asarray(rgb)
    except (UnidentifiedImageError, OSError) as exc:
        raise AcquisitionError("Nội dung tệp không phải ảnh hợp lệ.") from exc

    sha256 = hashlib.sha256(raw).hexdigest()
    qr_value = ""
    try:
        detector = cv2.QRCodeDetector()
        decoded, _, _ = detector.detectAndDecode(cv2.cvtColor(arr, cv2.COLOR_RGB2BGR))
        qr_value = (decoded or "").strip()
    except Exception:
        qr_value = ""

    token = f"att_{uuid.uuid4().hex[:20]}"
    metadata: dict[str, Any] = {
        "attachment_token": token,
        "kind": "QR_IMAGE" if qr_value else "IMAGE",
        "state": "QR_DECODED" if qr_value else "ACCEPTED_METADATA_ONLY",
        "sha256": sha256,
        "content_type": content_type,
        "format": fmt,
        "width": width,
        "height": height,
        "raw_file_persisted": False,
        "text_extraction": "NOT_PERFORMED",
        "limitations": (
            "QR decode chỉ trích xuất payload quan sát được; không xác nhận URL/tài khoản an toàn."
            if qr_value
            else "P3 không OCR ảnh chung. Ảnh được ghi nhận bằng fingerprint/metadata; raw bytes bị loại bỏ sau xử lý."
        ),
    }
    if qr_value:
        redacted = redact_secrets(qr_value)
        bounded = redacted.text[:512]
        metadata.update({
            "qr_payload_type": _classify_qr(bounded),
            "qr_payload": bounded,
            "qr_payload_truncated": len(redacted.text) > 512,
            "qr_secret_redacted": bool(redacted.redacted_types),
        })
    return token, metadata
