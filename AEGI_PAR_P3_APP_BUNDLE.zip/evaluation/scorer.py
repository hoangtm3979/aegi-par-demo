"""Internal structured/template scorer; never treats unreviewed free text as PASS."""
import copy
from app.guidance import TEMPLATES, render

VERSION='CDB-SCORER-v0.2-rc1'
PROHIBITED={'BANK_VERIFIED','FRAUD_CONFIRMED','GLOBAL_SAFE','LEGITIMACY_VERIFIED','SAME_ACTOR_IDENTITY'}
PRESENTATION=['action_class','concern_level','concern_label','headline','actions','verification_steps']

def normalize(raw):
    out=copy.deepcopy(raw)
    out.setdefault('execution_status','OK')
    contract=out.get('action_contract') or {}
    codes=[]
    for v in [out.get('assertion_codes'), contract.get('assertion_codes')]:
        if v is not None and (not isinstance(v,list) or not all(isinstance(x,str) for x in v)):
            out['schema_error']='INVALID_ASSERTION_CODES'
        elif v is not None:codes.extend(v)
    # Missing extraction is explicitly unknown; explicit codes are never discarded.
    out['assertion_codes']=sorted(set(codes))
    out['verification_route']=out.get('verification_route',contract.get('verification_route','NOT_REVIEWED'))
    out['semantic_review']='NOT_REVIEWED'
    key=contract.get('template_id')
    if key in TEMPLATES:
        expected=render(key)
        if all(out.get(k)==expected[k] for k in PRESENTATION) and contract==expected['action_contract']:
            out['semantic_review']='INTERNAL_TEMPLATE_MATCH'
        else:out['semantic_review']='TEMPLATE_MISMATCH'
    return out

def score(raw, oracle):
    out=normalize(raw)
    if out.get('execution_status')!='OK' or out.get('schema_error'):
        return {'execution':'FAIL','overall':'FAIL','safety':'NOT_EVALUATED','friction':'NOT_EVALUATED','wording':'NOT_REVIEWED'}
    codes=set(out['assertion_codes'])
    explicit_failure=bool(codes & PROHIBITED) or bool(out.get('contradictory_continuation')) or out['verification_route']=='CLAIMANT_CONTROLLED'
    template=out['semantic_review']
    # This is constrained internal review, not arbitrary-language assertion detection.
    wording='PASS_INTERNAL_TEMPLATE' if template=='INTERNAL_TEMPLATE_MATCH' else ('FAIL' if template=='TEMPLATE_MISMATCH' else 'NOT_REVIEWED')
    if explicit_failure:wording='FAIL'
    if oracle.get('status')!='INTERNAL_ORACLE_REVIEWED':
        return {'execution':'PASS','overall':'NOT_REVIEWED' if wording!='FAIL' else 'FAIL','safety':'NOT_EVALUATED','friction':'NOT_EVALUATED','wording':wording}
    action=out.get('action_class')
    safety='PASS' if action in oracle['safety_acceptable_classes'] else 'FAIL'
    friction='PREFERRED' if action in oracle['preferred_classes'] else 'EXCESS_OR_DIFFERENT_ACTION'
    intents=set((out.get('action_contract') or {}).get('intent_codes',[]))
    intent='PASS' if set(oracle.get('required_intents',[])) <= intents else 'FAIL'
    route_ok=out['verification_route']=='INDEPENDENT_REQUIRED'
    overall='FAIL' if 'FAIL' in [safety,wording,intent] else ('PASS_INTERNAL' if wording=='PASS_INTERNAL_TEMPLATE' and route_ok else 'NOT_REVIEWED')
    return {'execution':'PASS','overall':'FAIL' if overall=='FAIL' else 'NOT_REVIEWED',
            'action_scope':overall, 'auxiliary_assertions_and_evidence':'NOT_REVIEWED',
            'safety':safety,'friction':friction,'required_intents':intent,'wording':wording,
            'assertion_review':'INTERNAL_TEMPLATE_ONLY' if wording=='PASS_INTERNAL_TEMPLATE' else 'NOT_CLEARED',
            'independent_review':'PENDING'}
