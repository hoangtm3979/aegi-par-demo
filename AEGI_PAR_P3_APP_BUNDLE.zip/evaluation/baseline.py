"""B2 v0.2 local rules, same normalized observations as PAR.

Independent decision implementation, shared declared presentation catalog.
Not a provider product, independent reviewer or commercial comparator.
"""
from app.guidance import render

VERSION = 'CDB-B2-v0.3-rc3'

def decide(compiled, evidence):
    sem=compiled.get('semantic', {})
    pairs={(e['kind'],e['state']) for e in evidence}
    reliable=(('PROCEDURE_COMPARISON','MATCH') in pairs and ('ACCOUNT','REFERENCE_MATCH') in pairs
              and not any(k=='PROCEDURE_COMPARISON' and s in {'STALE','CONFLICTED','UNAVAILABLE','OUT_OF_SCOPE','SCOPE_UNKNOWN','PARTIAL_MATCH','WITHHELD_FOR_TEST'} for k,s in pairs))
    ambiguous=sem.get('version')!='PAR-SEMANTIC-CONTRACT-v0.3' or any(sem.get(f,'UNKNOWN')=='UNKNOWN' for f in ['credential_operation','remote_operation','pressure_kind'])
    explicit=sem.get('credential_operation')=='DISCLOSE_TO_CONTACT' or sem.get('remote_operation')=='REQUESTED_CONTROL' or sem.get('pressure_kind')=='COERCIVE'
    adverse=explicit or sem.get('concern_reported',False) or ('PROCEDURE_COMPARISON','DEVIATION') in pairs or ('OFFICIAL_SCENARIO_WARNING','MATCH') in pairs
    completed=compiled['action_state']=='ALREADY_TRANSFERRED'
    if sem.get('credential_compromise_reported') or sem.get('control_compromise_reported') or (completed and adverse):key='RECOVER'
    elif completed:key='COMPLETED_RECORD' if reliable and not ambiguous else 'COMPLETED_CHECK'
    elif explicit or ('PROCEDURE_COMPARISON','DEVIATION') in pairs or ('OFFICIAL_SCENARIO_WARNING','MATCH') in pairs:key='PREVENT'
    elif ambiguous or sem.get('concern_reported'):key='PAUSE'
    elif reliable:key='LIGHT'
    elif compiled['high_consequence']:key='PAUSE'
    else:key='GENERAL'
    return render(key)|{'evidence':evidence,'understood':compiled,'trace':{'policy_version':VERSION},'execution_status':'OK'}
