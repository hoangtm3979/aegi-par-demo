"""Post-adjustment regression only; no holdout, independence or population claims."""
import argparse
import collections
import copy
import dataclasses
import hashlib
import json
import sys
from pathlib import Path
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from app import engine
from app.guidance import render
from evaluation.baseline import decide as b2
from evaluation.scorer import score

SYSTEMS=['B0_ALWAYS_PAUSE','B2_RULES','PAR_CORE','PAR_WITHHOLD_PROCEDURE','PAR_WITHHOLD_REFERENCE']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def canon(v):return json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def stable(v):
    v=copy.deepcopy(v);v.pop('case_id',None);v.pop('performance',None);return v

def adapted(compiled,evidence,mode):
    evidence=copy.deepcopy(evidence)
    for e in evidence:
        if (mode=='PAR_WITHHOLD_PROCEDURE' and e['kind']=='PROCEDURE_COMPARISON') or (mode=='PAR_WITHHOLD_REFERENCE' and e['kind']=='ACCOUNT' and e['state']=='REFERENCE_MATCH'):
            e.update(state='WITHHELD_FOR_TEST',label='Intentionally withheld in development experiment',detail='Not a provider failure, NO_MATCH or NOT_APPLICABLE.',authority='CONTROLLED_WITHHOLDING',metadata={'original_evidence_id':e['evidence_id']})
    def lookup(kind,*args,**kwargs):
        return engine.EvidenceItem(**next(e for e in evidence if e['kind']==kind))
    def proc(*args,**kwargs):return [engine.EvidenceItem(**e) for e in evidence if e['kind']=='PROCEDURE_COMPARISON']
    def warn(*args,**kwargs):return [engine.EvidenceItem(**e) for e in evidence if e['kind']=='OFFICIAL_SCENARIO_WARNING']
    with patch.object(engine,'_compile_case',return_value=copy.deepcopy(compiled)),patch.object(engine,'_lookup_identifier',side_effect=lookup),patch.object(engine,'_education_procedure_evidence',side_effect=proc),patch.object(engine,'_official_warning_evidence',side_effect=warn),patch.object(engine,'_reviewed_memory_evidence',return_value=[]):
        return dataclasses.asdict(engine.decide('Instrumented development input',account='0000000000',action_state=compiled['action_state'],reviewed_memory_enabled=False,decision_date='2026-09-23'))

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',required=True,type=Path);args=ap.parse_args();out=args.out
    out.mkdir(parents=True,exist_ok=True)
    files=[*sorted((ROOT/'app').rglob('*.py')),*sorted((ROOT/'app/data').glob('*.json')),*sorted((ROOT/'evaluation').glob('*.py')),*sorted((ROOT/'evaluation').glob('*.json'))]
    write(out/'INPUT_MANIFEST.json',{'scope':'POST_ADJUSTMENT_REGRESSION','independent':False,'sealed':False,'files':{str(p.relative_to(ROOT)):sha(p) for p in files}})
    known=json.loads((ROOT/'evaluation/known_cases.json').read_text());legacy=json.loads((ROOT/'evaluation/legacy_packets.json').read_text())
    records=[];parity=[];replay=[]
    for c in known:
        setup=c['provider_setup'];kwargs=dict(account='0000000000' if setup=='UNKNOWN' else '999900001234567890',action_state=c['action_state'],identifier_source_available=setup!='UNAVAILABLE',procedure_state='STALE' if setup=='STALE' else 'CURRENT',reviewed_memory_enabled=False,decision_date='2026-09-23')
        native=dataclasses.asdict(engine.decide(c['text'],**kwargs));compiled=native['understood'];evidence=native['evidence']
        instrumented=adapted(compiled,evidence,'PAR_CORE')
        # Only intended decision/evidence fields; source flags and test account metadata differ by declared seam.
        keys=['action_class','concern_level','headline','actions','verification_steps','action_contract','evidence','understood']
        parity.append({'id':c['id'],'pass':all(native[k]==instrumented[k] for k in keys)})
        replay.append({'id':c['id'],'pass':stable(native)==stable(dataclasses.asdict(engine.decide(c['text'],**kwargs)))})
        for system in SYSTEMS:
            output=render('PAUSE') if system=='B0_ALWAYS_PAUSE' else b2(compiled,evidence) if system=='B2_RULES' else native if system=='PAR_CORE' else adapted(compiled,evidence,system)
            oracle=copy.deepcopy(c['oracle'])
            if system.startswith('PAR_WITHHOLD'):
                # Information-set change: no full-information LIGHT target is imposed on withheld evidence.
                if 'VERIFY_LIGHT' in oracle['preferred_classes'] or 'CONTINUE_CAUTION' in oracle['preferred_classes']:
                    oracle.update(safety_acceptable_classes=['PAUSE_VERIFY','PREVENT_VERIFY'],preferred_classes=['PAUSE_VERIFY'])
                oracle['scope']='CONDITIONAL_ON_WITHHELD_INFORMATION_INTERNAL'
            records.append({'id':c['id'],'system':system,'scope':'POST_ADJUSTMENT_KNOWN_CASE','oracle':oracle,'output':output,'score':score(output,oracle)})
    write(out/'KNOWN_RAW_AND_SCORES.json',records)
    old=[]
    for p in legacy:
        compiled=p['input']['compiled'];evidence=p['input']['evidence']
        for system in SYSTEMS:
            output=render('PAUSE') if system=='B0_ALWAYS_PAUSE' else b2(compiled,evidence) if system=='B2_RULES' else adapted(compiled,evidence,system)
            old.append({'episode_id':p['episode_id'],'system':system,'output':output,'assessment':'LEGACY_CONTRACT_MISSING_NOT_COMPARATIVE_SCORE'})
    write(out/'LEGACY_48_REPLAY.json',old)
    summary={s:{'n':len(rr), 'safety_constraints_pass':sum(r['score'].get('safety')=='PASS' for r in rr),
                'preferred_action':sum(r['score'].get('friction')=='PREFERRED' for r in rr),
                'required_intents_pass':sum(r['score'].get('required_intents')=='PASS' for r in rr),
                'whole_decision_unreviewed':sum(r['score'].get('overall')=='NOT_REVIEWED' for r in rr)}
             for s in SYSTEMS for rr in [[r for r in records if r['system']==s]]}
    result={'scope':'POST_ADJUSTMENT_REGRESSION_NOT_EFFECTIVENESS','known':summary,'legacy_records':len(old),
            'legacy_unique_consumed_inputs':len({canon({'compiled':p['input']['compiled'],'evidence':p['input']['evidence']}) for p in legacy}),
            'native_adapter_parity':parity,'native_repeat':replay,'independent_review':'PENDING','uplift_claim':'NOT_SUPPORTED'}
    write(out/'SUMMARY.json',result)
    assert all(v['pass'] for v in parity+replay)
    manifest=json.loads((out/'INPUT_MANIFEST.json').read_text())
    assert all(sha(ROOT/p)==h for p,h in manifest['files'].items())
    write(out/'OUTPUT_MANIFEST.json',{p.name:sha(p) for p in sorted(out.glob('*.json')) if p.name!='OUTPUT_MANIFEST.json'})
    print(json.dumps({'known':summary,'legacy_records':len(old),'parity':all(x['pass'] for x in parity),'repeat':all(x['pass'] for x in replay)},indent=2))

if __name__=='__main__':main()
