"""Local real HTTP acceptance with optional real browser; never calls public Railway."""
import argparse
import json
import os
import socket
import subprocess
import sys
import tempfile
import time
from pathlib import Path

import httpx

ROOT=Path(__file__).resolve().parent

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',required=True,type=Path);ap.add_argument('--browser',action='store_true');args=ap.parse_args()
    out=args.out;out.mkdir(parents=True,exist_ok=True)
    with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
    base=f'http://127.0.0.1:{port}'
    state=tempfile.TemporaryDirectory(prefix='par-rc1-http-')
    env=os.environ|{'PAR_STATE_DIR':state.name,'PAR_RATE_LIMIT_PER_MINUTE':'10000','PYTHONPATH':str(ROOT)}
    log=(out/'http_server.log').open('w')
    server=subprocess.Popen([sys.executable,'-m','uvicorn','app.main:app','--host','127.0.0.1','--port',str(port)],cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
    http_results=[];browser={'status':'NOT_RUN'}
    try:
        with httpx.Client(base_url=base,timeout=10,trust_env=False) as client:
            for _ in range(60):
                try:
                    if client.get('/api/v1/health').status_code==200:break
                except httpx.TransportError:pass
                time.sleep(.1)
            else:raise RuntimeError('Local server did not start')
            for path in ['/','/api/v1/health','/api/v1/readyz','/api/v1/about','/api/v1/demo/profiles','/static/app.js','/static/styles.css']:
                r=client.get(path);assert r.status_code==200
                assert r.headers['x-par-release']=='PAR-DEMO-P3-v0.4.2-rc4'
                http_results.append({'check':path,'status':'PASS'})
            cases=json.loads((ROOT/'evaluation/known_cases.json').read_text())
            # Source-availability/state fault controls are engine-only, not public API knobs.
            for c in cases:
                if c['provider_setup'] in ['UNAVAILABLE','STALE']:continue
                payload={'situation':c['text'],'account':'0000000000' if c['provider_setup']=='UNKNOWN' else '999900001234567890','action_state':c['action_state']}
                r=client.post('/api/v1/check',json=payload);assert r.status_code==200
                body=r.json();assert body['action_class'] in c['oracle']['preferred_classes']
                saved=client.get('/api/v1/cases/'+body['case_id']);assert saved.status_code==200
                assert saved.json()['trace']['decision_hash']==body['trace']['decision_hash']
                assert c['text'] not in json.dumps(saved.json(),ensure_ascii=False)
                ev=client.get('/api/v1/cases/'+body['case_id']+'/evidence');assert ev.status_code==200
                assert client.delete('/api/v1/cases/'+body['case_id']).json()['status']=='deleted'
                assert client.get('/api/v1/cases/'+body['case_id']).status_code==404
                http_results.append({'check':c['id'],'status':'PASS','action':body['action_class']})
            # QR behavior is carried through actual multipart HTTP, not a canned response.
            import qrcode
            from io import BytesIO
            image=BytesIO();qrcode.make('https://example.org/par-rc1-synthetic').save(image,format='PNG')
            r=client.post('/api/v1/uploads/image',files={'file':('fixture.png',image.getvalue(),'image/png')})
            assert r.status_code==200 and r.json()['attachment']['state']=='QR_DECODED'
            token=r.json()['attachment']['attachment_token']
            r=client.post('/api/v1/check',json={'situation':'Người gọi tự xưng Công an yêu cầu chuyển tiền để xác minh.','action_state':'NOT_STARTED','attachment_tokens':[token]})
            assert r.status_code==200 and any(e['state']=='QR_DECODED' for e in r.json()['evidence'])
            http_results.append({'check':'REAL_HTTP_QR_UPLOAD_BIND','status':'PASS'})
        if args.browser:
            try:
                from playwright.sync_api import sync_playwright
                with sync_playwright() as pw:
                    launch={'headless':True,'args':['--no-sandbox','--disable-dev-shm-usage']}
                    if os.getenv('PAR_BROWSER_EXECUTABLE'):
                        launch['executable_path']=os.environ['PAR_BROWSER_EXECUTABLE']
                    if os.getenv('PAR_BROWSER_ARGS_JSON'):
                        launch['args']=json.loads(os.environ['PAR_BROWSER_ARGS_JSON'])
                    b=pw.chromium.launch(**launch)
                    browser_version=b.version
                    checks=[]
                    for width,height in [(1440,1000),(390,844)]:
                        page=b.new_page(viewport={'width':width,'height':height})
                        page.goto(base);page.wait_for_selector('.proof-card')
                        page.screenshot(path=str(out/f'browser_home_{width}.png'),full_page=True)
                        page.locator('button[data-profile="hero2_legitimate_unfamiliar"]').click(timeout=5000)
                        page.locator('#checkForm button[type="submit"]').click();page.wait_for_selector('#result.active')
                        assert page.locator('.action-class').inner_text()=='VERIFY_LIGHT'
                        assert page.evaluate('document.documentElement.scrollWidth <= window.innerWidth + 1')
                        page.wait_for_function("() => window.scrollY <= 1 && getComputedStyle(document.querySelector('#toast')).opacity === '0'")
                        page.evaluate('document.fonts.ready')
                        page.screenshot(path=str(out/f'browser_{width}.png'),full_page=True)
                        checks.append({'viewport':width,'hero2':'PASS','overflow':'PASS'})
                        page.close()
                    b.close();browser={'status':'PASS','checks':checks,'mode':'REAL_BROWSER_REAL_LOCAL_HTTP','browser_version':browser_version}
            except Exception as exc:
                browser={'status':'BLOCKED_OR_FAILED','error':str(exc)[:1200],'pass_claim':False}
        (out/'HTTP_ACCEPTANCE.json').write_text(json.dumps({'status':'PASS','checks':http_results,'mode':'REAL_LOCAL_HTTP','public_runtime':'NOT_TESTED'},ensure_ascii=False,indent=2)+'\n')
        (out/'BROWSER_ACCEPTANCE.json').write_text(json.dumps(browser,ensure_ascii=False,indent=2)+'\n')
        print(json.dumps({'http_checks':len(http_results),'http':'PASS','browser':browser['status']}))
        if args.browser and browser['status'] != 'PASS':
            raise RuntimeError('Requested browser acceptance did not pass; inspect BROWSER_ACCEPTANCE.json')
    finally:
        server.terminate()
        try:server.wait(timeout=10)
        except subprocess.TimeoutExpired:server.kill();server.wait()
        log.close();state.cleanup()

if __name__=='__main__':main()
