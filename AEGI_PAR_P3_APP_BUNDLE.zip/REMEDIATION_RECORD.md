# PAR — disposition F01–F09 — v0.4.2-rc1

Date: 23/09/2026. User authorised implementation after PAR-CDB-REVIEW-001.

**IMPLEMENTED FOR BOUNDED INTERNAL ACCEPTANCE.** Đây là thay đổi candidate/demo và evaluation harness; không sửa doctrine lõi, không tự mở Gate v0.5, không promote GitHub/Railway. Evidence pack riêng ghi kết quả từ exact source ZIP.

| Finding | Thay đổi đã triển khai | Disposition và giới hạn |
|---|---|---|
| F01 — policy | Hazard cụ thể được xét trước positive reference; câu hướng dẫn gồm không tiết lộ credential/không cấp quyền, tuyến xác minh độc lập. | BOUNDED_FIX_IMPLEMENTED; chờ independent review. |
| F02 — compiler | Thêm semantic contract có distinction, unknown, local negation/contrast và provenance offsets; không gọi mọi OTP là disclosure. | BOUNDED_FIX_IMPLEMENTED; rule coverage hữu hạn, không đóng claim hiểu ngôn ngữ tổng quát. |
| F03 — scope | Check institution ID, reported channel, declared purpose, extra actions, recipient và validity date. | BOUNDED_FIX_IMPLEMENTED; một fixture trường demo, user-reported channel chưa được provider xác minh. |
| F04 — recovery | Completed chỉ recovery khi concern/compromise; completed clean giữ biên lai, thiếu dữ kiện thì clarification. | BOUNDED_FIX_IMPLEMENTED; không cam kết thu hồi tiền. |
| F05 — diversity | Harness tính unique compiled/evidence, giữ legacy 48 ở track riêng, không coi token bỏ qua là identifier test. | METHOD_CORRECTED; vẫn thiếu independent diverse corpus. |
| F06 — oracle | Tách safety-compatible action, preference/friction, required intents; ambiguous scope giữ clarification. | INTERNAL_METHOD_IMPLEMENTED; oracle cùng tác giả, không phải gold độc lập. |
| F07 — B2 | Rule selection riêng trên cùng contract/evidence; recovery có đúng hướng dẫn; dùng chung presentation catalog đã khai báo. | INTERNAL_BASELINE_REPAIRED; không phải nTrust hoặc superiority evidence. |
| F08 — scorer | Bảo toàn codes, kiểm tra route/contradiction/template mutation; text không review hoặc auxiliary assertions chưa chấm không thành overall PASS. | FAIL_CLOSED_STATUS_IMPLEMENTED; full semantic extractor và independent assertion review DEFERRED. |
| F09 — ablation | WITHHELD_FOR_TEST tách khỏi NOT_APPLICABLE/NO_MATCH; oracle conditional trên information set. | SENSITIVITY_METHOD_CORRECTED; không gọi là complete component contribution. |

## Authority/claim continuity

**REVISED:** remediation chưa triển khai → candidate nội bộ đã triển khai, kết quả exact-ZIP nằm trong acceptance report riêng. Lỗi safety còn hiện diện trong source v0.4.1 lịch sử; không sửa lại nhận định đó thành “v0.4.1 đã an toàn”.

**STILL VALID:** historical CDB counts, review findings và giới hạn independent evidence; Gate v0.5 REVISE và sealed NOT_AUTHORISED. 48 packet cũ và 14 ca review đã exposure, không được đưa vào holdout bằng cách đổi ID.

**SUPERSEDED trong candidate:** behavior-unchanged gate của semantic-only v0.4.1. v0.4.2-rc1 có intentional behavior changes và positive demo input mới; M01/M02 vẫn được kiểm tra.

## Development corrections retained in this record

- Dependency pin OpenCV trong v0.4.1 là `4.13.0`, không cài được qua index sử dụng; candidate sửa `4.13.0.92`, lock đầy đủ môi trường test.
- Trong vòng implementation trước freeze đã sửa thiếu field action_contract khi khởi tạo result, và cấu hình HTTP test dùng direct loopback thay proxy môi trường. Không có deployment bị thay đổi.
- Browser Playwright download từ CDN không thành công trong môi trường này. Acceptance có tùy chọn executable Chromium và ghi version thực dùng; browser PASS chỉ được ghi khi đã chạy thành công.
- Các bài test cũ giữ nguyên nghĩa trừ release identity và hai expectation Hero 2 thiếu scope; test semantic-only cũ được archive dạng text, không giả cho nó PASS.

## Conditions for next evidence tier

Để chạy tiếp internal challenge: dùng candidate/hash cố định, chọn cấu trúc chưa dùng để patch, ghi oracle trước chạy; báo cáo sai lệch và kết quả âm. Cùng trợ lý tạo case/chấm không được gọi independent.

Để mở calibration/sealed: vẫn cần con người độc lập, nguồn benign/harmful phù hợp, stability measurement, temporal lookup state, configuration freeze và gate hiện hành. Không có outcome/human-effect/commercial uplift claim từ acceptance.

- UI giữ native `[hidden]` để không hiện resume/upload placeholder khi chưa có dữ liệu; screenshot chờ kết thúc scroll/toast transition. Browser acceptance được yêu cầu mà fail sẽ trả nonzero exit.
