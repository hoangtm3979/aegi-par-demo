# PAR rc4 remediation

Scope: candidate-only correction after Internal Evaluation Kit v0.2 first-run.

Fix families:
1. Password/credential language and privacy redaction boundary.
2. Colloquial remote-control completion and control negation.
3. Colloquial transfer abbreviation `ck` and bounded generic-code sharing to a contact.

No benchmark claim. No baseline claim. No change to the original 24-case oracle/scorer.
