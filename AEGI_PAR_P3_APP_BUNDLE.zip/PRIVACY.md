# Privacy Boundary — P3

- Raw user situation text is not persisted in the case store.
- Raw uploaded image bytes are discarded after bounded inspection.
- Persisted case state contains redacted decision-result metadata and trace information under TTL.
- Default TTL is 24 hours and is configurable.
- Users can explicitly delete a case.
- No login, VNeID, bank identity, telco identity or institutional private identifier is required.
- The public trial warns users not to enter OTP, password, PIN or CVV.
- The trial site is marked no-index/no-archive to reduce accidental discoverability.

These are P3 implementation boundaries, not a statement of compliance certification under any privacy regime.
