#!/usr/bin/env sh
set -eu
HOST="${HOST:-0.0.0.0}"
PORT="${PORT:-8000}"
FORWARDED="${PAR_FORWARDED_ALLOW_IPS:-*}"
exec uvicorn app.main:app --host "$HOST" --port "$PORT" --proxy-headers --forwarded-allow-ips="$FORWARDED" --no-server-header --no-access-log
