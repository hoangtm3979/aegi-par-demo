"""Real browser interaction with new clarification path, no external requests."""
import os,sys,tempfile,subprocess,socket,time,json
from pathlib import Path
import httpx
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parent
out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=True)
with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
checks=[]
with tempfile.TemporaryDirectory() as state:
 env=os.environ|{'PAR_STATE_DIR':state,'PAR_RATE_LIMIT_PER_MINUTE':'10000'}
 with (out/'server.log').open('w') as log:
  server=subprocess.Popen([sys.executable,'-m','uvicorn','app.main:app','--host','127.0.0.1','--port',str(port)],cwd=ROOT,env=env,stdout=log,stderr=log)
  try:
   url=f'http://127.0.0.1:{port}'
   for _ in range(100):
    try:
     if httpx.get(url+'/api/v1/health',trust_env=False).status_code==200:break
    except httpx.TransportError:pass
    time.sleep(.05)
   with sync_playwright() as p:
    browser=p.chromium.launch(executable_path=os.environ['PAR_BROWSER_EXECUTABLE'],args=['--no-sandbox','--disable-dev-shm-usage'])
    for viewport in ({'width':1280,'height':900},{'width':390,'height':844}):
     page=browser.new_page(viewport=viewport);errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
     page.goto(url);page.locator('[data-entry="recovery"]').first.click()
     assert page.locator('#actionState').input_value()=='UNKNOWN';checks.append('recovery_entry_not_payment_yes')
     page.locator('#situation').fill('Tôi cần kiểm tra lời người gọi đang yêu cầu tôi.')
     page.locator('#checkForm button[type="submit"]').click();page.locator('#clarifyForm').wait_for()
     page.get_by_label('Đã chuyển tiền',exact=True).select_option('NO')
     page.get_by_label('Đã đọc/gửi mã hoặc mật khẩu cho người khác',exact=True).select_option('YES')
     page.get_by_label('Đã cho người khác truy cập tài khoản hoặc điều khiển thiết bị',exact=True).select_option('NO')
     with page.expect_response(lambda r:'/api/v1/check' in r.url and r.request.method=='POST') as resp:
      page.get_by_role('button',name='Cập nhật câu trả lời',exact=True).click()
     data=resp.value.json();assert data['action_class']=='RECOVER';assert data['understood']['semantic']['exposure']=={'payment':'NO','credential':'YES','control':'NO'}
     page.wait_for_function("document.querySelector('.action-class').textContent==='RECOVER'")
     checks.append('clarification_recovery_without_transfer')
     assert page.evaluate('document.documentElement.scrollWidth<=window.innerWidth');checks.append('no_horizontal_overflow')
     assert not errors;checks.append('no_browser_exceptions')
     page.screenshot(path=str(out/f"clarification-{viewport['width']}.png"),full_page=True)
     page.reload();page.locator('#resumeCase').click();page.locator('#result.active').wait_for()
     assert page.locator('#resultMount').inner_text().find('Đã đọc/gửi mã')>=0;checks.append('saved_result_resume')
     page.close()
    browser.close()
  finally:server.terminate();server.wait(timeout=10)
(out/'RESULT.json').write_text(json.dumps({'status':'PASS','checks':checks,'count':len(checks),'scope':'internal browser acceptance, not human usability'},ensure_ascii=False,indent=2))
print('Interpretation browser acceptance:',len(checks),'PASS')
