# AEGI PAR P3 v0.4.2-rc4 — recovery/language correction candidate

Internal, behavior-changing candidate. Not deployed; not a sealed benchmark result.

## Implemented
- Single bounded clause/event compiler with source offsets over folded/redacted transient text.
- Current request vs negation, quoted warning, hypothetical, historical and third-party context.
- Independent payment/credential/control exposures: YES, NO, UNKNOWN, CONFLICT.
- Existing evidence fixtures and action templates; unavailable is not safe; reference is not verification.
- Typed exposure answers in API and UI; conflicting self-report cannot clear an exposure identified in the description.
- Up to two clarification groups (one contains three fields); not evidence of low user friction.
- Effective procedure state separate from catalog status.

## Run
Python 3.12 recommended. Create a venv, `pip install -r requirements-lock.txt`, then `python -m uvicorn app.main:app --host 127.0.0.1 --port 8000`.
Run `python -m pytest -q`; `python acceptance_runtime.py --out ./local-acceptance --browser`.
Run `python acceptance_interpretation.py ./interpretation-acceptance` with PAR_BROWSER_EXECUTABLE pointing to Chromium.
Use synthetic inputs only. No real authority/provider integration is added.

## Evidence boundaries
The companion evidence package owns measured results. Tests are development checks, not independent annotation. B2 receives the same compiled evidence and cannot establish interpreter superiority. All earlier challenge results remain historical evidence. Unknown natural-language expressions, complex quotation/negation, multiple people/transactions and colloquial language remain a risk. No general-language completeness claim.
Source manifests bind packaged bytes. Old remediation documents under historical or named REMEDIATION_RECORD describe rc1 only; this README and the companion rc2 report describe the new candidate.


## rc4 correction
Internal Evaluation Kit v0.2 exposed bounded language/recovery defects in password disclosure, colloquial remote-control completion, `ck`/generic-code phrasing, and negation scope. rc4 corrects those parser boundaries without changing the evidence authority model, decision-action templates, data fixtures, reviewed-memory behavior, or benchmark claims. The original 24-case internal suite is development-exposed regression only; a separately prelocked fresh internal confirmation set is also development-only and not sealed/independent evidence.

## rc3 repair
Challenge-002 first run on frozen rc2: action/exposure combined 14/16. N03 and N04 retained unknown exposures but selected CONTINUE_CAUTION. rc3 treats reference-only/hypothetical-only text with no active request as unresolved and asks for clarification. The same 16 cases are now exposed regression. See companion report; no fresh-test claim for rc3.
