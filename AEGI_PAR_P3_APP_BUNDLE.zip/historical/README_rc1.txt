# AEGI PAR P3 v0.4.2-rc1 — remediation candidate

Candidate phát triển nội bộ từ P3 v0.4.1. Có thay đổi hành vi quyết định; **không phải semantic-only patch**, không phải production promotion. Áp dụng review PAR-CDB-REVIEW-001 trong phạm vi code demo và phương pháp đánh giá nội bộ.

## Nội dung

- Contract ngữ nghĩa có version: disclosure/self-entry/denied/unknown; coercion/deadline/unknown; requested control/self-install/unknown. Giữ nguồn là mô tả chưa xác minh và offsets trên văn bản đã redaction; không lưu raw text.
- Procedure fixture phải bao phủ tổ chức, kênh được mô tả, mục đích, requested actions, recipient và thời hạn. REFERENCE_MATCH không xác minh identity/ownership.
- Policy ưu tiên yêu cầu nguy hiểm cụ thể; recovery cần dấu hiệu concern/compromise cùng trạng thái hành động, không chỉ ALREADY_TRANSFERRED.
- Baseline B2 có decision rules riêng trên cùng compiled/evidence; dùng chung catalog câu hướng dẫn đã khai báo để tránh khác biệt chỉ do wording. Đây không phải implementation hoặc đánh giá độc lập hoàn toàn.
- Scorer giữ assertion codes, tách safety constraints/friction/intents và phát hiện template bị sửa. Văn bản chưa review không được tự PASS. `overall=NOT_REVIEWED` vẫn giữ cho auxiliary assertions/evidence; không báo cáo full-decision correctness hoặc UAR.
- Bộ hồi quy 14 ca đã biết; 48 packet cũ giữ nguyên bytes, chạy riêng dưới nhãn legacy contract missing. Không nâng legacy flags thành ngữ nghĩa đã xác nhận.
- Withholding có trạng thái WITHHELD_FOR_TEST, oracle có điều kiện theo thông tin còn lại; không dùng làm component-uplift proof.

## Chạy local

Đã chuẩn bị cho Python 3.12; kết quả môi trường kiểm tra đi kèm evidence pack. Dockerfile gốc Python 3.13 được giữ lại nhưng cần acceptance riêng trước deploy.

```sh
python3 -m venv .venv
. .venv/bin/activate
pip install -r requirements-lock.txt
python -m pytest -q
python evaluation/run.py --out /tmp/par-rc1-regression
python acceptance_runtime.py --out /tmp/par-rc1-http
bash run_demo.sh
```

Mở `http://127.0.0.1:8000`. Không dùng dữ liệu thật cho demo. Để kiểm tra UI: cài browser Playwright, rồi chạy `python acceptance_runtime.py --out /tmp/par-rc1-browser --browser`. Có thể đặt `PAR_BROWSER_EXECUTABLE` tới Chromium đã có; kết quả ghi identity browser thực tế.

Manifest nguồn khóa mọi file trong ZIP. Chạy kiểm tra trong bản sao hoặc ghi evidence ra thư mục ngoài để bảo toàn snapshot nguồn. Requirements lock là môi trường acceptance; requirements-prod giữ direct dependencies. Pin OpenCV cũ `4.13.0` không resolve trên package index đã dùng; candidate sửa thành `4.13.0.92`. Các dependency khác không bị nâng chủ ý.

## Thay đổi acceptance so với v0.4.1

- Test semantic-only behavior-unchanged v0.4.1 được giữ ở historical/*.txt; không còn là gate đúng cho behavior-changing rc1. M01/M02 được kiểm tra lại trong suite mới.
- Hai test Hero 2 cũ không có channel được đổi kỳ vọng sang clarification. Positive demo mới thêm việc tự mở cổng chính thức để đối chiếu; không được nói candidate giữ nguyên hành vi trên input cũ.
- Các ca OTP/app có thao tác hợp lệ nhưng chưa xác lập kênh trong procedure vẫn PAUSE_VERIFY để làm rõ. Đối chứng bổ sung cùng procedure/channel đầy đủ xác nhận chúng không bị hard-stop vì keyword.
- Oracle được sửa trong giai đoạn phát triển sau khi đã biết kết quả cũ. Đây là POST_ADJUSTMENT_REGRESSION, không preregistration hay sealed evidence.

## Giới hạn còn lại

Rule-based language interpretation chỉ bao phủ các biểu thức đã hỗ trợ. Không chứng minh hiểu tiếng Việt tổng quát, mọi phủ định/phát ngôn trích dẫn/actor hoặc mọi câu tấn công. Provenance offsets không tự chứng minh cách hiểu đúng. Trust là user-reported; fixture chỉ có Minh An demo, không phải knowledge base thủ tục quốc gia.

Chưa có reviewer độc lập, human-effect evidence, real benign corpus, provider integrations, production/container acceptance hay phép so sánh với nTrust. Reviewed memory không được đánh giá lại về incremental value. Calibration/sealed Gate v0.5 giữ nguyên; không có GO pilot hoặc claim PAR > baseline từ gói này.

## Quyền và trạng thái

Source candidate và local acceptance không thay thế registry authority, submission freeze, GitHub commit, Railway deployment hay video. Kết quả CDB v0.1 và Internal Review v0.1 được giữ nguyên. Report triển khai trong evidence pack nối identity candidate với các lần kiểm tra thật.
